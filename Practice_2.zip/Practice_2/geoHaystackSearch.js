// Example of a simple geoHaystackSearch query across some documents

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Fetch the collection
 var collection = db.collection('simple_geo_haystack_command');
 
 collection.insertMany([{a:1, loc:[50,30]},{a:2, loc:[30,50]}], {w:1}, function(err, result){
	 console.log('Inserted', result);
	
	collection.ensureIndex({loc: "geoHaystack", type: 1}, {bucketSize: 1}, function(err, result) {
	
		collection.geoHaystackSearch(50,50, {search: {a:1}, limit:1, maxDistance:100}, function(err, docs) {
			console.log('docs :', docs);
			console.log('err :', err);
			db.close();
		});
	});	
 })
});
// A simple example showing the use of next.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Create a collection
  var collection = db.collection('simple_next_object_collection_with_next');

  // Insert some documents we can sort on
  collection.insertMany([{a:1}, {a:2}, {a:3}], {w:1}, function(err, docs) {
    test.equal(null, err);
	var cursor = collection.find();
	
	cursor.hasNext(function(err, r){
		console.log(r);
		
		cursor.next(function(err, r1){
			console.log('r1',r1);
			db.close();
			
			cursor.next(function(err, r2){
				console.log('r2',r2);
				db.close();
			})
			
		})
	})
    
  });
});
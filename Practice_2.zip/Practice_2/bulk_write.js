// Example of a simple bulkWrite operation

var Mongodb = require('mongodb');
var MongoClient = Mongodb.MongoClient;
var test = require('assert');


MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
	var col = db.collection('bulk_write');
	
	col.bulkWrite([
		      { insertOne: { document: { a: 1 } } }
			, { updateOne: { filter: {a:2}, update: {$set: {a:2}}, upsert:true } }
			, { updateMany: { filter: {a:2}, update: {$set: {a:2}}, upsert:true } }
			, { deleteOne: { filter: {c:1} } }
			, { deleteMany: { filter: {c:1} } }
			, { replaceOne: { filter: {c:3}, replacement: {c:4}, upsert:true}}]
		,{ordered:true, w:1}
		, function(err, r){
			test.equal(null, err);
			
			console.log(r);
			
			test.equal(1, r.nInserted);
			test.equal(2, r.nUpserted);
			test.equal(0, r.nRemoved);

			// Crud fields
			test.equal(1, r.insertedCount);
			test.equal(1, Object.keys(r.insertedIds).length);
			test.equal(1, r.matchedCount);
			test.equal(0, r.modifiedCount);
			test.equal(0, r.deletedCount);
			test.equal(2, r.upsertedCount);
			test.equal(2, Object.keys(r.upsertedIds).length);

    // Ordered bulk operation
    db.close();
		}
	);
});
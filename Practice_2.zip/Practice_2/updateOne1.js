// Example of a simple document update with safe set to false on an existing document

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var test = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('update_a_simple_document');
	collection.insertMany([{a:1,b:1}, {a:2,b:2} ], function(err, doc){
		collection.updateOne({a:1}, {$set : {a:3}} );
		
		setTimeout(function() {
			collection.findOne({a:3}, function(err, item) {
				console.log('item', item)
			test.equal(null, err);
			//test.equal(3, item.a);
			//test.equal(1, item.b);
			db.close();
      });
    }, 1000);
	});
});
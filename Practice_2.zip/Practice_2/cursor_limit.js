// A simple example showing the use of limit on the cursor

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  var collection = db.collection('simple_limit_collection');
  
  collection.insertMany([{a:1},{b:2},{c:3}], {w:1}, function(err, docs){
	  console.log(docs);
	  
	  var cursor = collection.find().limit(1);
	  cursor.toArray(function(err, data){
		  console.log('data',data);
		  db.close();
	  })
  })
});
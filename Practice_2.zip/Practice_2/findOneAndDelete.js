var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Get the collection
  var col = db.collection('find_one_and_delete');
	col.insertMany([{a:1, b:1}], {w:1}, function(err, r) {
		test.equal(null, err);
		test.equal(1, r.result.n);
		console.log('r', r);
		
		col.findOneAndDelete({a:1}, {projection: {b:1,a:1}, sort: {a:1} }, function(err, r) {
			console.log('delete',r.value)
		})
		
	db.close();
	})
  
  
  });
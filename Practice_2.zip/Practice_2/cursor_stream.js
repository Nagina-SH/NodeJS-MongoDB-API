// A simple example showing the use of the cursor stream function.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

var docs = [];
for (var i=0; i<100; i++) {
	docs.push({'a':i})
}

var collection = db.collection('test_strem_function');

collection.insertMany(docs, {w:1}, function(err, ids){
	var stream = collection.find().stream();
	
	stream.on('end', function(){
		console.log('db closed now');
		db.close();
	});
	
	stream.on('data', function(data){
		console.log('retrive data on by one');
		console.log('data');
	});
})

});
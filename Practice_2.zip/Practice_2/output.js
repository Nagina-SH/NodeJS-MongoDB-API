 Collection {
  s:
   { pkFactory:
      { [Function: ObjectID]
        index: 2168557,
        createPk: [Function: createPk],
        createFromTime: [Function: createFromTime],
        createFromHexString: [Function: createFromHexString],
        isValid: [Function: isValid],
        ObjectID: [Circular],
        ObjectId: [Circular] },
     db:
      Db {
        domain: null,
        _events: {},
        _eventsCount: 0,
        _maxListeners: undefined,
        s: [Object],
        serverConfig: [Getter],
        bufferMaxEntries: [Getter],
        databaseName: [Getter] },
     topology:
      Server {
        domain: null,
        _events: [Object],
        _eventsCount: 7,
        _maxListeners: undefined,
        clientInfo: [Object],
        s: [Object] },
     dbName: 'test',
     options: { promiseLibrary: [Function: Promise] },
     namespace: 'test.dropExample1',
     readPreference:
      ReadPreference {
        _type: 'ReadPreference',
        mode: 'primary',
        tags: undefined,
        options: undefined },
     slaveOk: true,
     serializeFunctions: undefined,
     raw: undefined,
     promoteLongs: undefined,
     promoteValues: undefined,
     promoteBuffers: undefined,
     internalHint: null,
     collectionHint: null,
     name: 'dropExample1',
     promiseLibrary: [Function: Promise],
     readConcern: undefined } }

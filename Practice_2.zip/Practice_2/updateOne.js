// Example of a simple updateOne operation

var Mongodb = require('mongodb');
var MongoClient = Mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test',function(err, db){
	var collection = db.collection('update_one');
	collection.updateOne({a:1}, {$set: {a:3}}, {upsert:true}, function(err, r){
		console.log('r', r);
		db.close();
	});
});
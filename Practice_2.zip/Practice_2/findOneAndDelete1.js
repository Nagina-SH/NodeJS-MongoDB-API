// Example of a simple findOneAndDelete operation

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('find_one_and_delete1');
	collection.insertMany([{a:1, b:1}], {w:1}, function(err, r) {
		assert.equal(null, err);
		assert.equal(1, r.result.n);
		console.log('Inserted:', r);
		//db.close();
		collection.findOneAndDelete({a:1}, function(err, r){
			console.log('Deleted:', r);
		    db.close();
		});
		
	})

});
// Correctly call the aggregation using a cursor


var mongodb = require('mongodb');
var MongoClient = mongodb.MongoClient;

assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
	// Some docs for insertion
	var docs = [{
      title : "this is my title", author : "bob", posted : new Date() ,
      pageViews : 5, tags : [ "fun" , "good" , "fun" ], other : { foo : 5 },
      comments : [
        { author :"joe", text : "this is cool" }, { author :"sam", text : "this is bad" }
      ]}];
	
	// create collection
	var collection = db.collection('aggregationExample2');
	// remove documents from collections
	//collection.remove ({});
	// insert the docs
	collection.insertMany (docs, {w:1}, function(err, data) {
		//console.log('data', data);
		
		var cursor = collection.aggregate([
        { $project : {
          author : 1,
          tags : 1
        }},
        { $unwind : "$tags" },
        { $group : {
          _id : {tags : "$tags"},
          authors : { $addToSet : "$author" }
        }}
      ], { cursor: { batchSize: 1 } });
		// get all the aggregation results
		
		cursor.toArray(function(err, docs) {
			assert.equal(null, err);
			assert.equal(2, docs.length);
			db.close();
		})
		
	})
	
	
})
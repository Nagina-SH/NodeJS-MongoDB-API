// A simple example showing the use of the cursor explain function.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Create a collection
  var collection = db.collection('simple_explain_collection');

  // Insert some documents we can sort on
  collection.insertMany([{a:1}, {a:2}, {a:3}], {w:1}, function(err, docs) {
    test.equal(null, err);

    // Do normal ascending sort
    collection.find().explain(function(err, explaination) {
      test.equal(null, err);
		console.log('explaination',explaination);
      db.close();
    });
  });
});
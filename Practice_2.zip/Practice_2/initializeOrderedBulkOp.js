// Example of a simple ordered insert/update/upsert/remove ordered collection

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var test = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){

	var collection = db.collection('batch_write_ordered_ops_0');

	var batch = collection.initializeOrderedBulkOp();

	batch.insert({a:1});
	batch.find({a:1}).updateOne({$set: {b:1}});
	batch.find({a:2}).upsert().updateOne({$set: {b:2}});
	batch.insert({a:3});
	batch.find({a:3}).remove({a:3});
	
	batch.execute(function(err, result) {
		console.log(result);
		var upserts = result.getUpsertedIds();
		console.log('upserts',upserts.length);
		test.equal(1, upserts.length);
		test.equal(2, upserts[0].index);
		test.ok(upserts[0]._id != null);

		
		db.close();
	})
})  
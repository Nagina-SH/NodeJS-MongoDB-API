article

db.article.insert([
{
 title : "this is my title" ,
 author : "bob" ,
 posted : new Date () ,
 pageViews : 5 ,
 tags : [ "fun" , "good" , "fun" ] ,
 comments : [
             { author :"joe" , text : "this is cool" } ,
             { author :"sam" , text : "this is bad" }
 ],
 other : { foo : 5 }
}
])

db.article.aggregate(
	{$project : {
		author : 1,
		title :1,
		tags : 1
	}},
	{$unwind : "$tags"}
);

{ "_id" : ObjectId("5a4dca010e01fcb737dbf039"), "title" : "this is my title", "author" : "bob", "tags" : "fun" }
{ "_id" : ObjectId("5a4dca010e01fcb737dbf039"), "title" : "this is my title", "author" : "bob", "tags" : "good" }
{ "_id" : ObjectId("5a4dca010e01fcb737dbf039"), "title" : "this is my title", "author" : "bob", "tags" : "fun" }



db.article.aggregate(
	{$project : {
		author : 1,
		title :1,
		tags : 1,
		pageViews :1
	}},
	{$unwind : "$tags"},
	{ $group : {
          _id : {tags : "$tags"},
          num_tutorial : {$sum : "$pageViews" }
        }}

);
{ "_id" : { "tags" : "good" }, "num_tutorial" : 5 }
{ "_id" : { "tags" : "fun" }, "num_tutorial" : 10 }

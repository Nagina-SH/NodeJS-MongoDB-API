var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('simple_next_object_collection');
	collection.insertMany([{a:1},{a:2},{a:3}], {w:1}, function(err, docs) {
		
		var cursor = collection.find().sort({'a' : 1}).skip(1);
		cursor.nextObject(function(err, r1){
			console.log('r1',r1);
			
			cursor.nextObject(function(err, r2){
				console.log('r2',r2);
				db.close();
			});
			
			
		});
	});
});
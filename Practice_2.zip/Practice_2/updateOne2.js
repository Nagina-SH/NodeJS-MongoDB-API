// Example of a simple updateOne operation

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Get the collection
  
  var collection = db.collection('update_one2');
  
  collection.updateOne(
	{a:2},
	{$set: {c:1}},
	{upsert:true}
	, function(err, r){
	  console.log('r',r);
	  db.close();
  });
  
});
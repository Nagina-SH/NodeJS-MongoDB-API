var mongodb = require('mongodb');

var MongodbClient = mongodb.MongoClient;

var assert = require('assert');

MongodbClient.connect('mongodb://localhost:27017/test', function(err, db) {
	var collection = db.collection('countExample1');

collection.remove({}, function(err, ids){	
	collection.insertMany([{a:1},{a:2},{a:3},{a:4, b:11}], {w:1},  function(err, ids) {
		//perform a total count method
		collection.count(function(err, count){
			assert.equal(null, err);
			assert.equal(4, count);
			db.close();
		})
	})
})

});
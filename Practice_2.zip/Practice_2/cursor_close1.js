// A simple example showing the use of the cursor close function using a Promise.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Create a lot of documents to insert
  var docs = []
  for(var i = 0; i < 100; i++) {
    docs.push({'a':i})
  }

  // Create a collection
  var collection = db.collection('test_close_function_on_cursor_with_promise');

  // Insert documents into collection
  collection.insertMany(docs, {w:1}).then(function(ids) {
    // Peform a find to get a cursor
    var cursor = collection.find();

    // Fetch the first object
    cursor.nextObject().then(function(object) {
		console.log('object',object);
      // Close the cursor, this is the same as reseting the query
      cursor.close().then(function(result) {
		  console.log(result);
        db.close();
      });
    });
  });
});
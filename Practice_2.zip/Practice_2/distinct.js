var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Crete the collection for the distinct example
  var collection = db.collection('distinctExample1');

  // Insert documents to perform distinct against
  collection.insertMany([{a:0, b:{c:'a'}}, {a:1, b:{c:'b'}}, {a:1, b:{c:'c'}},
    {a:2, b:{c:'a'}}, {a:3}, {a:3}], {w:1}, function(err, ids) {

    // Peform a distinct query against the a field
    collection.distinct('a', function(err, docs) {
      test.deepEqual([0, 1, 2, 3], docs.sort());

      // Perform a distinct query against the sub-field b.c
      collection.distinct('b.c', function(err, docs) {
        test.deepEqual(['a', 'b', 'c'], docs.sort());
		console.log('docs', docs);

        db.close();
      });
    });
  });
});
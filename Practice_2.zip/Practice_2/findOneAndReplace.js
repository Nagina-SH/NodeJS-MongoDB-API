// Example of a simple findOneAndReplace operation

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Get the collection
  var col = db.collection('find_one_and_replace');
  col.insertMany([{a:1, b:1}], {w:1}, function(err, r) {
    test.equal(null, err);
    test.equal(1, r.result.n);
	console.log('Inserted', r);
	
    col.findOneAndReplace({a:1,b:1}
      , {c:1, b:1}
      , {
            projection: {a:1}
          , sort: {a:1}
          , returnOriginal: true
		  //, returnOriginal: false
          , upsert: true
        }
      , function(err, r) {
        test.equal(null, err);
        test.equal(1, r.lastErrorObject.n);
       // test.equal(1, r.value.b);
       // test.equal(1, r.value.c);
		console.log('Deleted', r);

        db.close();
    });
  });
});
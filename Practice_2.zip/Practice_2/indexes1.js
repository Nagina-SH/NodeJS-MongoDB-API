// Example of retrieving a collections indexes using a Promise.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Crete the collection for the distinct example
  var collection = db.collection('simple_key_based_distinct_with_promise');

  // Create a geo 2d index
  collection.ensureIndex({loc:"2d"}, {w:1})
  .then(function(result){
	  console.log('result:', result);
	  
	  collection.ensureIndex({a:1},{w:1})
	  .then(function(result){
		  console.log('result:', result);
		  
		  setTimeout(function(){
			  collection.indexes()
			  .then(function(indexes){
				  console.log(indexes);
				  db.close();
			  })
		  },100);
	  })
  });
  
});  


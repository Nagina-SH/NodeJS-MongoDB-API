//group(keys, condition, initial, reduce, finalize, command, options, callback){Promise}


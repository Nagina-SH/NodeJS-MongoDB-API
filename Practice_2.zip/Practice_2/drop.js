// Example of a simple collection drop.

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
	var collection = db.collection('test_other_drop');
	
	collection.drop(function(err, done) {
		
		db.listCollections().toArray(function(err, data) {
			var found = false;
			data.forEach(function(document) {
				console.log(`document : ${document.name}`);
				if(document.name == "test_other_drop"){
					found = true;
					return;
				}
			});
			assert.equal(false, found);
			db.close();
		});
	});
});
var mongodb = require('mongodb');

var MongodbClient = mongodb.MongoClient;

var assert = require('assert');

MongodbClient.connect('mongodb://localhost:27017/test', function(err, db) {
	var collection = db.collection('countExample1_with_promise');
	
	collection.remove({}, function(err, ids){
		collection.insertMany([{a:1},{a:2,b:1},{c:3}], {w:1})
		.then(function(ids){
			//perform a total count command
			collection.count()
			.then(function(count){
				assert.equal(3, count);
				db.close();
			})
		})
	});	
})
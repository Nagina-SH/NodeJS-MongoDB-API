// Example of running the distinct command against a collection with a filter query

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Crete the collection for the distinct example
  var collection = db.collection('distinctExample2');

  // Insert documents to perform distinct against
  collection.insertMany(
						[
						{a:0, b:{c:'a'}}, 
						{a:1, b:{c:'b'}}, 
						{a:1, b:{c:'c'}},
						{a:2, b:{c:'a'}}, 
						{a:3}, 
						{a:3}, 
						{a:5, c:1}
						], 
						{w:1}, function(err, ids) {

    // Peform a distinct query with a filter against the documents
    collection.distinct('a', {b:{c:'a'}}, function(err, docs) {
      test.deepEqual([0,2], docs.sort());
	  
	  console.log('docs',docs);

      db.close();
    });
  })
});
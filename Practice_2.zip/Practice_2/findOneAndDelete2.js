// Example of a simple findOneAndDelete operation using a Promise

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Get the collection
  var collection = db.collection('find_one_and_delete_with_promise');
  collection.insertMany([{a:1,b:1},{a:1,b:2}], {w:1})
  .then(function(r){
	  console.log('Inserted doc', r);
	  
	  collection.findOneAndDelete({a:1}, {sort: {b:1} })
	  .then(function(r){
		  console.log('deleted', r);
		  db.close();
	  })
	  
	  
  })
});
// An example of illegal and legal renaming of a collection

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;
var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	// Open a couple of collections
	db.createCollection('test_rename_collection', function(err, collection1){
		db.createCollection('test_rename_collection2', function(err, collection2){
			try{
				collection1.rename('test_rename_collection3', function(err, collection){
					console.log('collection1',collection1);
					db.close();
				})
			} catch(err) {
				console.log('err',err);
			}	
		});
	});
});

// A more complex createIndex using a compound unique index in the background and dropping duplicated documents

var Mongodb = require('mongodb');

var MongoClient = Mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('createIndexExample1');

collection.remove({}, function(err, data){	
	collection.insertMany([{a:1, b:1}, {a:2, b:2}, {a:3,b:3}],{w:1}, function(err, result){
		assert.equal(err, null);
		
		collection.createIndex({a:1,b:1}, {unique:true, background:true, w:1}, function(err, indexNAme) {
			// Show that duplicate records got dropped
			collection.find({}).toArray(function(err, items) {
				assert.equal(null, err);
				assert.equal(3, items.length);
				db.close();
			})
		})
	})
})

});


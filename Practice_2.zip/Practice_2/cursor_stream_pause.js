// A simple example showing the use of the cursorstream pause function.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Create a lot of documents to insert
  var docs = []
  var fetchedDocs = [];
  for(var i = 0; i < 2; i++) {
    docs.push({'a':i})
  }

  // Create a collection
  var collection = db.collection('test_cursorstream_pause');

  // Insert documents into collection
  collection.insertMany(docs, {w:1}, function(err, ids) {
    // Peform a find to get a cursor
    var stream = collection.find().stream();

    // For each data item
    stream.on("data", function(item) {
      fetchedDocs.push(item)
      // Pause stream
      stream.pause();

      // Restart the stream after 1 miliscecond
      setTimeout(function() {
        fetchedDocs.push(null);
        stream.resume();
      }, 1);
    });

    // When the stream is done
    stream.on("end", function() {
      test.equal(null, fetchedDocs[1]);
      db.close();
    });
  });
});
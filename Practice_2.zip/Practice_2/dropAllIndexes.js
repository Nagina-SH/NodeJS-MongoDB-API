// Example of a how to drop all the indexes on a collection using dropAllIndexes

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('createAllIndex');
	collection.insertMany([
							{a:1, b:1},
							{a:3, b:3},
							{a:2, b:2},
							{a:3, b:3},
							{a:4, b:4}
							], 
							{w:1}, 
							function(err, result) {
								assert.equal(null, err);
								collection.createIndex({a:1,b:1}, {unique:false, background:true, w:1}, function(err, indexName) {
									console.log('indexName', indexName);
									console.log('err', err);
									
									collection.dropAllIndexes(function(err, reply){
										assert.equal(null, err);
									});
									
									db.close();
								})
							})
	
});
// Example of retrieving a collections indexes

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Crete the collection for the distinct example
  var collection = db.collection('simple_key_based_distinct');
  // Create a geo 2d index
  collection.ensureIndex({loc:"2d"}, {w:1}, function(err, result) {
    test.equal(null, err);

    // Create a simple single field index
    collection.ensureIndex({a:1}, {w:1}, function(err, result) {
      test.equal(null, err);
	console.log('ERROR', err);
	
	setTimeout(function() {
		// List all of the indexes on the collection
		collection.indexes(function(err, indexes){
			console.log('indexes', indexes);
			db.close();
		});
	},1);
	
	
    });
  });
});
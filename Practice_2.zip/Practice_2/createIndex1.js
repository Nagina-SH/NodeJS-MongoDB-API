// A more complex createIndex using a Promise and a compound unique index in the background and dropping duplicated documents

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var test = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
	var collection = db.collection('createIndexExample2');
	
	collection.insertMany([{a:1, b:1},{a:3, b:3}
    , {a:2, b:2}, {a:3, b:3}, {a:4, b:4}], {w:1}, function(err, result) {
    
	test.equal(null, err);
	// create an index on the a field
	
	collection.createIndex({a:1,b:1}, {unique:true, background:true, w:1}, function(err, indexName) {
		// show that duplicate records got dropped
		collection.find({}).toArray(function(err, items) {
			test.equal(null, err);
			test.equal(5, items.length);
			console.log('indexName',indexName );
			// Peform a query, with explain to show we hit the query
			
			// Peform a query, with explain to show we hit the query
			collection.find({a:2}).explain(function(err, explanation) {
          test.equal(null, err);
          test.ok(explanation != null);

			console.log('explanation' , explanation);
			
			db.close();
			
			})
		})
	})
})

});
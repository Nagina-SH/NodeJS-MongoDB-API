// A simple example showing the use of batchSize on the cursor, batchSize only regulates how many
// documents are returned for each batch using the getMoreCommand against the MongoDB server

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

	var collection = db.collection('simple_batch_size_collection');
	collection.insertMany([{a:1,b:1},{a:2,b:2},{a:3,b:3}], {w:1}, function(err, docs){
		//console.log(docs);
		
		collection.find().batchSize(2).nextObject(function(err, item){
			console.log('item',item);
		})
		
	})
	
});
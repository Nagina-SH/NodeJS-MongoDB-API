// A simple example showing the count function of the cursor.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Creat collection
  var collection = db.collection('cursor_count_collection');

  // Insert some docs
  collection.insertMany([{a:1}, {a:2}], {w:1}, function(err, docs) {
    test.equal(null, err);

    // Do a find and get the cursor count
    collection.find().count(function(err, count) {
      test.equal(null, err);
      test.equal(2, count);

      db.close();
	  
    })
  });
});
// A whole set of different ways to use the findAndModify command.
// The first findAndModify command modifies a document and returns the modified document back.
//The second findAndModify command removes the document.
//The second findAndModify command upserts a document and returns the new document.


var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('simple_find_and_modify_operations');
	
	collection.insertMany([{a:1}, {b:1}, {c:1}], {w:1}, function(err, result) {
	assert.equal(null, err);
		collection.findAndModify({a:1}, [['a', 1]], {$set: {b1:1}}, {new:true}, function(err, doc) {
			console.log('doc', doc)
			db.close();
		})
	});
});
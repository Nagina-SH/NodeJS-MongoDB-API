var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

// MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	// var collection = db.collection('simple_next_object_collection');
	// collection.insertMany([{a:1},{a:2},{a:3}], {w:1}, function(err, docs) {
		// collection.find().nextObject(function(err, item1) {
			// console.log('item1', item1);
			
			// collection.find().nextObject(function(err, item2) {
				// console.log('item2', item2);
				// db.close();
			// })
		// })
	// })
// })


MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('simple_next_object_collection');
	collection.insertMany([{a:1},{a:2},{a:3}], {w:1}, function(err, docs) {
		
		var cursor = collection.find().skip(1);
		cursor.nextObject(function(err, r1){
			console.log('r1',r1);
			
			cursor.nextObject(function(err, r2){
				console.log('r2',r2);
				db.close();
			});
			
			
		})
	})
})
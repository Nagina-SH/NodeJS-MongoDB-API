// Example of a simple findOneAndUpdate operation using a Promise.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {
  // Get the collection
  var collection = db.collection('find_one_and_update_with_promise');
  collection.insertMany([{a:2,b:1},{a:2,b:2}],{w:1})
  .then(function(r){
	  //test.equal(2, r.result.n);
	  
	  collection.findOneAndUpdate(
		{a:2}
	  , {$set: {c:4}}
	  ,{
		  $sort: {a:1}
		, upsert: true
		}
	  ).then(function(r) {
		  console.log('updated:', r);
		  db.close();
	  })
  })
});
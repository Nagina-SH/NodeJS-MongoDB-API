// Example of Collection.prototype.drop using a Promise

var mongodb = require('mongodb');
var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	db.createCollection('test_other_drop_with_promise')
	.then(function(collection) {
		collection.drop()
		.then(function(done){
			db.listCollections().toArray()
			.then(function(data){
				var found = false;
				data.forEach(function(document){
					if(document.name == 'test_other_drop_with_promise'){
						found = true;
						return;
					}
				});
				
				assert.equal(found, false);
				db.close();
			})
		})
	})
});
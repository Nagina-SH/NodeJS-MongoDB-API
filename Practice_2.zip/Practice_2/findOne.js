var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('find_on_query');
	
	collection.insertMany([{a:1, b:1}, {a:2, b:2}, {a:3, b:3}], {w:1}, function(err, result) {
		assert.equal(null, err);
		
		collection.findOne({a:2}, function(err, docs){
			console.log('docs', docs);
		})
	});
});
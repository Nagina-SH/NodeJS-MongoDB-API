// Correctly call the aggregation using a read stream

var mongodb = require('mongodb');
var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	// Some docs for insertion
  var docs = [{
      title : "this is my title", author : "bob", posted : new Date() ,
      pageViews : 5, tags : [ "fun" , "good" , "fun" ], other : { foo : 5 },
      comments : [
        { author :"joe", text : "this is cool" }, { author :"sam", text : "this is bad" }
      ]}];
	// Execute aggregate, notice the pipeline is expressed as an Array

	var collection = db.collection('aggregationExample3');
	collection.insert(docs, {w:1}, function (err, result){
		var cursor = collection.aggregate([
        { $project : {
          author : 1,
          tags : 1
        }},
        { $unwind : "$tags" },
        { $group : {
          _id : {tags : "$tags"},
          authors : { $addToSet : "$author" }
        }}
      ], { cursor: { batchSize: 1 } });
		
	var count = 0;
	cursor.on('data', function(doc) {
		count = count+1;
		console.log('doc :', doc);
	});
		
	cursor.once('end', function() {
      assert.equal(2, count);
      db.close();
	});	
});

});
// A simple example iterating over a query using the each function of the cursor.

var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('test_to_a_after_each');
	collection.insertMany([{a:1, b:1},{a:2,b:2},{a:3,b:3}], {w:1}, function(err, ids){
		var cursor = collection.find();
		
		cursor.each(function(err, item){
			console.log('item', item);
			if(item = null){
				cursor.toArray(function(err, item){
					console.log('itemnull',item);
					db.close();
				})
			};
			
		});
		
	});
});
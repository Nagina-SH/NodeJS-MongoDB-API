// A simple query showing skip and limit


var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

var assert = require('assert');

MongoClient.connect('mongodb://localhost:27017/test', function(err, db){
	var collection = db.collection('simple_limit_skip_query');
	collection.insertMany([{a:2, b:1}], {}, function(err, result) {
		assert.equal(null, err);
		
		collection.find({}).sort({"$a" : 1}).project({b:1})
		.toArray(function(err, docs) {
			console.log('docs', docs);
			db.close();
		});
		
	});
	
});
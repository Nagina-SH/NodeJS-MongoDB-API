// An example showing the information returned by indexInformation using a Promise.

var MongoClient = require('mongodb').MongoClient,
  test = require('assert');
MongoClient.connect('mongodb://localhost:27017/test', function(err, db) {

  // Create a collection to hold our documents
  var collection = db.collection('test_array_with_promise');

  collection.insertOne({'b': [1,2,3]}, {w:1}, function(err, data){
	  //console.log(data);
	  
	  collection.find().toArray(function(err, data){
		  console.log(data);
		  console.log(data[0].b);
		  test.deepEqual([1,2,3], data[0].b);
		  
		  db.close();
	  })
  })
});
var fs = require('fs');

var domain1 = require('domain');
var domain = domain1.create();

domain.run(function () {
	fs.readFile('', 'utf8', function(err, data) {
	if(err) {
		throw err;
	}
	
	console.log(data);
	domain.dispose();
	
	});
});
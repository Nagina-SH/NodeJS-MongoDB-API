var events = require('events');

var eventEmitter = new events.EvenEmitter();

eventEmitter.on ('scream', function() {
	console.log('A scream is detected!');
});

evenEmitter.emit('scream');

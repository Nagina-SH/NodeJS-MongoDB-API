//client1.js...associated with server.js
var io = require('socket.io-client');
var socket = io.connect('http://localhost:3000', {reconnect: true});

// Add a connect listener
socket.on('connect', function (socket) {
    console.log('Client2 Connected!');
});
socket.emit('Client2', 'Shailendra', 'test2');


socket.on('newclientconnect',function(data) {
         console.log(data.description);
      });

socket.on('newUser',function(data) {
    console.log('newUser :', data.description);
});

socket.on('UserJoined',function(data) {
         console.log('newUser :', data.description);
		});  

socket.emit('newUser', { description : 'I am new user from client 2' });		
var buf = new Buffer(4);
buf[0] = 0;
buf[1] = 1;

console.log(buf);
console.log(buf[0]);
console.log(buf[1]);
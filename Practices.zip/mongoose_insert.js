var mongoose = require("mongoose");
var connection = mongoose.createConnection("mongodb://localhost/test");
//var Person = require(__dirname + "/mongoose_PersonModel").getModel(connection);

var db = mongoose.connection;


connection.on("open", function( ) {
console.log("Connection established");
	//connection.close( );
});
 
db.on('error', function (err) {
console.log('connection error', err);
});
db.once('open', function () {
console.log('connected.');
});



var {user} = require('./mongoose_PersonModel');

var user_insert = new user({
SSN: "123-45-6789",
LastName: "Pluck",
FirstName: "Peter",
Gender: "M",
City: "Pittsburgh",
State: "PA",
Vehicles: [
{
VIN: 12345,
Type: "Jeep",
Year: 2014
},
{
VIN: 98032,
Type: "Car",
Year: 2006
}
]
});

user_insert.save(function(err, data) {
	if(err){
		console.log(err);
	} else {
		console.log('Saved : ', data)
	}
});
process.argv.forEach(function(arg, index) {
console.log("argv[" + index + "] = " + arg);
});
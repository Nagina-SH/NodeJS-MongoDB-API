var foo = new ArrayBuffer(4);
foo[0] = 0;
foo[1] = 1;
foo[2] = 2;
foo[3] = 3;


for (var i = 0, len = foo.byteLength; i < len; i++) {
	console.log(foo[i]);
}


for (var i = 1, len = foo.byteLength; i<len+1; i++) {
	console.log(foo[len-i]);
	
}


// (function foo() {
	// (function bar() {
		// (function baz() {
			// console.trace("test-trace");
		// })();
	// })();
// })();

// console.trace('Show me');

console.log("foo");
console.error("bar");

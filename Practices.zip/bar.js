bar_mod1 = function bar() {
console.log("Inside of bar1() function");
};

bar_mod2 = function bar() {
console.log("Inside of bar2() function");
};

console.log("Inside of file");

module.exports = [bar_mod1, bar_mod2];
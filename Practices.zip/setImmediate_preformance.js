var i = 0;
function compute() {
if (i < 10000) {
// perform some computation
i++;
	// if(i=100) {
		// console.log(`i: `, i);
		
	// }
setImmediate(compute);
}
}
compute();
console.log("compute() still working…");
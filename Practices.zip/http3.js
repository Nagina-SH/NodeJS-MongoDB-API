var http = require("http");
var qs = require("querystring");
var body = qs.stringify({
foo: "bar",
baz: [1, 2]
});
var request = http.request({
hostname: '127.0.0.1',
port: 8000,
path: "/",
method: "POST",
headers: {
"Host": "127.0.0.1:8000",
"Content-Type": "application/x-www-form-urlencoded",
"Content-Length": Buffer.byteLength(body)
}
}, function(response) {
response.setEncoding("utf8");
response.on("data", function(data) {
process.stdout.write(data);
});
response.on("end", function() {
console.log();
});
});
request.end(body);
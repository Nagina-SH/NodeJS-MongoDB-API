// var foo = new ArrayBuffer(4);
// foo[0] = 0;
// foo[1] = 1;
// foo[2] = 2;
// foo[3] = 3;
// console.log(foo.slice(2, 4));
// console.log(foo.slice(2, foo.byteLength));
// console.log(foo.slice(2));
// console.log(foo.slice(-2));


var foo = new ArrayBuffer(4);
var bar;
foo[0] = 10;
foo[1] = 11;
foo[2] = 21;
foo[3] = 31;
// Create a copy of foo and modify it
bar = foo.slice(1,4);
bar[0] = 0xc;
console.log(foo);
console.log(bar);
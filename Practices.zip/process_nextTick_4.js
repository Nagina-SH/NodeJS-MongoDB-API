function isNegative(n, cb) {
process.nextTick(function() {
cb(n < 0);
});
}
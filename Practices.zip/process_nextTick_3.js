function isNegative(n, cb) {
if (n < 0) {
process.nextTick(function() {
	//console.log(n);
cb(true);
});
}
cb(false);
}

//isNegative(5);


function isNegative(n, cb) {
if (n < 0) {
return process.nextTick(function() {
cb(true);
});
}
return process.nextTick(function() {
cb(false);
});
}
var async = require('async');
 
var results = [];

function f1() {
setTimeout(function() {
console.log("Task 1");
results[0] = 1;
}, 300);
}

function f2() {
setTimeout(function() {
console.log("Task 2");
results[1] = 2;
}, 400);
}

function f3() {
setTimeout(function() {
console.log("Task 3");
results[2] = 3;
}, 300);

}

// async.series(
// [f1(), f2(), f3()], function(err, data) {
	// console.log(data);
// }
// )




async.series([
    f2,
    f1
], function (err, results) {
    // Here, results is an array of the value from each function
    console.log(results); // outputs: ['two', 'five']
});
var net = require('net');

var server = net.createServer(function(socket) {
	server.on('error', function(error) {
		
		console.log(error);
		if (error.code === 'EADDRINUSE') {
		console.error("Port is already in use");
		} else {
			console.error("Error aay ahe bhai...dekh le..!");
		}
			
	});
	
	//socket.end('Hello and goodbye!');

});

server.listen(8000);
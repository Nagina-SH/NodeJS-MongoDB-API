var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var PersonSchema = new Schema({
	SSN: String,
	LastName: String,
	FirstName: String,
	Gender: String,
	City: String,
	State: String,
	Vechicles: [{
			VIN: number,
			Type: String,
			Year: Number
	}]
});
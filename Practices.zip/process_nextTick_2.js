process.nextTick(function(f, b) {
console.log(f + " " + b);
});
// prints "undefined undefined"

function getFunction(f, b) {
return function myNextTick() {
console.log(f + " " + b);
};
}
process.nextTick(getFunction("foo", "bar"));
// prints "foo bar"
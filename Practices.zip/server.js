//server.js
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

io.on('connection', function (socket){
   console.log('connection on server');

  socket.on('Client1', function (from, msg) {
    console.log('Client1-MSG', from, ' saying ', msg);
	
	  
  });
	
	
  });
  
  socket.on('Client2', function (from, msg) {
    console.log('Client2-MSG', from, ' saying ', msg);
  });

  
  
});

http.listen(3000, function () {
  console.log('listening on *:3000');
});
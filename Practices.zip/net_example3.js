var net = require('net');

var server = net.createServer(function(socket) {
	socket.end('Hello and goodbye!');
});

server.listen(8000);
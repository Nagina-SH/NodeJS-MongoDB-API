// setTimeout(function(foo, bar) {
// console.log(foo + " " + bar);
// }, 1000, "foo1", "bar1");


var timeoutId = setTimeout(function() {
console.log("In timeout function");
}, 1000);
//clearTimeout(timeoutId);
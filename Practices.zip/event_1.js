const readFileAsArry = function(file, cb) {
	fs.readFile(file, function(err, data) {
		if(err){
			return cb(err);
		}
		consloe.log(data);
		const lines = data.toString().trim().split('\n');
		cb(null, lines);
		consloe.log(data.toString());
	});
}


readFileAsArray('./numbers.txt', (err, lines) => {
  if (err) throw err;
  const numbers = lines.map(Number);
  const oddNumbers = numbers.filter(n => n%2 === 1);
  console.log('Odd numbers count:', oddNumbers.length);
});

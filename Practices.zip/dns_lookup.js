var dns = require('dns');

var domain = 'google.com';

dns.lookup(domain, 4, function(err, address, familay) {
	if(err){
		console.log(`dns lookup failed with code {$err.code}`);
	} else{
		console.log(`${domain}   =>   ${address}`);
	}
});
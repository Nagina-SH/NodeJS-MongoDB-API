var net = require('net');
var server = net.createServer(function(socket) {
// handle connections
});

server.listen(0, '::1', function() {
	var address = server.address();
	console.log(address);
	console.log('Listening on port '+ address.port);
});
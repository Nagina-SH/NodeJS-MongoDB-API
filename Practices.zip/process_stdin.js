process.stdin.once('data', function(data) {
	
	var response = data.toString();
	console.log('You said your name is '+ response);
	process.stdin.pause();
	
});

console.log('What is youe name');
process.stdin.setEncoding("utf8");
//process.stdin.resume();
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var PersonSchema = new Schema({
	SSN: String,
	LastName: String,
	FirstName: String,
	Gender: String,
	City: String,
	State: String,
	Vehicles: [{
		VIN: Number,
		Type: String,
		Year: Number
	}]
});

var getModel = function getModel(connection){
	return connection.model("Person",PersonSchema);
}

var Person_1 = mongoose.model('Person_1', PersonSchema);

module.exports = {
	getModel : getModel,
	Person_1 : Person_1
}

var user = mongoose.model('user', PersonSchema);

module.exports = {
	user
};
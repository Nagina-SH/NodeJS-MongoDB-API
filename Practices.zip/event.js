var events = require('events');

var emitter = new events.EventEmitter();

var username = 'Test_user';
var password = 'Test@pass';

// an event listener

emitter.on('userAdded', function(username,password ) {
	console.log(`User Added into Database`, username);
});

// Then emit the event
emitter.emit('userAdded', username, password);
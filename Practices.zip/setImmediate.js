var immediateId = setImmediate(function() {
console.log("In immediate function");
});

clearImmediate(immediateId);
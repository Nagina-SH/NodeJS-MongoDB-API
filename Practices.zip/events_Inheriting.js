var EventEmitter = require("events").EventEmitter;
var util = require("util");
function UserEventEmitter() {
EventEmitter.call(this);
this.addUser = function(username, password) {
// add the user
console.log('User Added');
// then emit an event
this.emit("userAdded", username, password);
};
};
util.inherits(UserEventEmitter, EventEmitter);
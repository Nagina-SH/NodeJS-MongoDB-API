// setInterval(function() {
// console.log("foo");
// }, 500);
// setInterval(function() {
// console.log("bar");
// }, 1000);


setInterval(function() {
console.log("foo");
while (true) {
}
}, 1000);

setInterval(function() {
console.log("bar");
}, 1000);
var byteLength = Buffer.byteLength("foo");
var length = (new Buffer("foo")).length;
console.log(byteLength);
console.log(length);
console.log('-----------------');
var buf = new Buffer(1024);
buf.fill(0);
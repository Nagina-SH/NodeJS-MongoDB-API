var express = require('express');

var app = express();

//to make a http server object
var server = require('http').createServer(app);

//to make our socket.io module
var io = require('socket.io').listen(server);


app.get('/', function(req, res){
	res.sendFile(__dirname + '/chat_index.html')
})


server.listen(3000, function(){
	console.log(`server is running on port 3000`);
});
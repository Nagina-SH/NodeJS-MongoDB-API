var commander = require("commander");
commander
.option("-f, --foo <i>", "Integer value for foo", parseInt, 20)
.option("-b, --bar [j]", "Integer value for bar", parseInt, 10)
.option("-z, --baz", "Boolean argument baz")
.parse(process.argv);
console.log(commander.foo);
console.log(commander.bar);
console.log(commander.baz);
var MongoClient = require('mongodb').MongoClient;

// Connect to the db
// MongoClient.connect("mongodb://mean:Jobchange@ds115446.mlab.com:15446/shailu_mean", function (err, db) {
   
     // if(err) throw err;

     // console.log(`Database connected`);
                
// });


MongoClient.connect("mongodb://localhost:27017/MongoDB", function (err, db) {
   
     if(err) throw err;

     console.log(`Database connected`);
                
});

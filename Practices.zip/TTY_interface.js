console.warn("stdin = " + process.stdin.isTTY);
//console.warn("stdout = " + process.stdout.isTTY);
console.warn("stderr = " + process.stderr.isTTY);
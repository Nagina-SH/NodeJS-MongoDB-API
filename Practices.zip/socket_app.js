var app = require('express');
var http = require('http').Server(app);

app.get('/', function(req, res) {
	res.send('test');
});

http.listen(3000);
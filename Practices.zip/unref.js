var intervalid = setInterval(function() {
	console.log(`In interval function`);
}, 1000);

//intervalid.unref();
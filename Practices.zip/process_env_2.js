var devMode = !!process.env.DEVELOPMENT;
if (devMode) {
console.log("Some useful debugging information");
}
var buf = new Buffer(9);
var data = 'foo';

buf.write(data);
console.log(buf);
console.log('----------');
buf.write(data,3);
console.log(buf);
console.log('----------');
buf.write(data, 6, data.length);

console.log(buf);

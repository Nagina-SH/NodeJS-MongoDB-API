process.nextTick(function() {
console.log("Executing tick n+1");
});
console.log("Executing nth tick");
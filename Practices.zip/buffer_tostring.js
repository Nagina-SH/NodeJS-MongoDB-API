// var buf = new Buffer("foo");
// console.log(buf.toString());

var buf = new Buffer(1);
console.log(Buffer.isBuffer(buf));

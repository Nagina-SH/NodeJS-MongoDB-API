var net = require("net");
var client = net.connect({
port: 8000,
host: "localhost",
allowHalfOpen: false
});

// var client = net.connect(8000, function() {
	// console.log("Local endpoint " + client.localAddress + ":" +client.localPort);
	// console.log("is connected to");
	// console.log("Remote endpoint " + client.remoteAddress + ":" + client.remotePort);
// });

client.on('end', function() {
console.log("end handler");
client.end();
});
client.on('close', function(error) {
console.log("close handler");
console.log("had error: " + error);
});
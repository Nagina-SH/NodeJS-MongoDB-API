var events = require("events");
var emitter = new events.EventEmitter();
emitter.on("foo", function() {
console.log("foo handler");
});
emitter.removeListener("foo", function() {
console.log("foo handler1");
});
emitter.emit("foo");
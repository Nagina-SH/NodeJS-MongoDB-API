var commander = require("commander");
var list = ["foo", "bar", "baz"];
commander.choose(list, function(index) {
console.log("You selected " + list[index]);
process.stdin.pause();
});
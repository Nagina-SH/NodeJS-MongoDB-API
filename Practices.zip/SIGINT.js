process.on("SIGINT", function() {
console.log("Got a SIGINT signal");
});
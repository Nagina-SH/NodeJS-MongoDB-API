var http = require('http');

var server = http.createServer(function (req, res) {
	res.write('hello <strong>HTTP </strong>');
	
	var reqline = req.method + ' ' +req.url + 'HTTP:/' 
	//+ req.httpVersion
	;
	console.log(reqline);
	
	res.end();
});

server.listen(8000);
var dns = require("dns");
var domain = "google.com";
dns.resolve(domain, "AAAA", function(error, addresses) {
if (error) {
console.error("DNS lookup failed with code AAAA" + error.code);
} else {
console.log(domain + " -> " + addresses);
}
});

dns.resolveMx(domain, "MX", function(error, addresses) {
if (error) {
console.error("DNS lookup failed with code MX " + error.code);
} else {
console.log(domain + " MX -> " + addresses);
}
});


dns.resolveSrv(domain, "SRV", function(error, addresses) {
if (error) {
console.error("DNS lookup failed with code SRV  " + error.code);
} else {
console.log(domain + " SRV-> " + addresses);
}
});


dns.resolveNs(domain, "NS", function(error, addresses) {
if (error) {
console.error("DNS lookup failed with code NS" + error.code);
} else {
console.log(domain + " NS-> " + addresses);
}
});
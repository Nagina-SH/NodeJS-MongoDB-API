console.log("This file is " + __filename);
console.log("It's located in " + __dirname);
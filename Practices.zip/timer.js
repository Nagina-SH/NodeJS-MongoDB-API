setTimeout(() => {  
  console.log('timer.js');
}, 20000);
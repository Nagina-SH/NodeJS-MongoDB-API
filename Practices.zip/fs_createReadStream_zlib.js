var fs = require("fs");
var zlib = require("zlib");

var input = fs.createReadStream("foo.txt");

var gzip = zlib.createGzip();

var output_zip = fs.createWriteStream("foo.txt.gz");

input.pipe(gzip).pipe(output_zip);




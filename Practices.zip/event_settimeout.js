var events = require('events');
 var emitter = events.EventEmitter;
 
 var e = new emitter();
 
 function loopprocessor(num) {
	 
	 setTimeout(function() {
		for (var i=1; i<=num; i++) {
			e.emit('BeforeProcess', i);


			console.log('Processing number:' + i);
			
			e.emit('AfterProcess', i);
			console.log('------------------------------');
		} 
	 }
	 , 2000)
	 
	 return e;
 }
 
var lp = loopprocessor(3);

lp.on('BeforeProcess', function (data) {
    console.log('About to start the process for ' + data);
});

lp.on('AfterProcess', function (data) {
    console.log('Completed processing ' + data);
});
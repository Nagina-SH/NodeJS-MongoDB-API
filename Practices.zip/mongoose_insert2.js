var mongoose = require('mongoose');
var db = require('./db/db');

var { userSchema, appSchema } = require('./routes/mongoose_schema');




//create the model

var User = mongoose.model('User', userSchema);
var appSchema = mongoose.model('appSchema', appSchema);

var chris = new appSchema({
  name: 'Admin',
  username: 'shailendra10',
  password: 'password' 
});


appSchema.findOneAndRemove({ username: 'shailendra999' }, function(err) {
  if (err) throw err;

  // we have deleted the user
  console.log('User deleted!');
});

// appSchema.findOneAndUpdate({username: 'shailendra99'}, {username: 'shailendra999'},function(err, data){
		// if(err) throw err;
		// console.log('Updated User: ', data);
	
// });


// appSchema.find({username: 'shailendra999'}, function(err, users) {
		// if(err) throw err;
		// console.log('Users :', users)
	// });

// appSchema.findById('5a3222217f2e8c270008bde3', function(err, data){
	// if(err) throw err;
	
	// data.location = 'uk';
	
	// data.save(function(err){
		// if(err) throw err;
		// console.log('User successfully updated');
	
	// appSchema.find({location : 'uk'}, function(err, users) {
		// if(err) throw err;
		// console.log('Users :', users)
	// });
	
	// });
	
	
// });



// chris.save(function(err) {
  // if (err) throw err;

  // console.log('User saved successfully!');
  
  
  // appSchema.find({username: 'shailendra10'}, function(err, users) {
	// if(err){
		// throw err;
	// }
	
	// console.log(users);
// });
  
// });


// appSchema.find({}, function(err, users) {
	// if(err){
		// throw err;
	// }
	
	// console.log(users);
// })


// Thats it, our User model is ready. 
// We will use this as our base schema to insert users into the database. 
// This way we know that every document in a User collection will 
// have the fields listed on the schema. Lets create a new user 
// instance and save it to DB add



// var Insert_data = new User({
	// name : 'Shailendra',
	// age: 38,
	// DOB: '01/01/1989'
// });

// Insert_data.save(function(err, data) {
	// if(err){
		// console.log(err);
	// } else {
		// console.log('Saved : ', data );
	// }
// });

// // use of schema method
// console.log('FindAge : ',Insert_data.findAge());

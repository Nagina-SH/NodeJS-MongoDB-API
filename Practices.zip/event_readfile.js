var events = require('events');
var fs = require('fs');

var eventsEmitter = new events.EventEmitter();

eventsEmitter.on('read', readFileContent);
eventsEmitter.on('display', DisplayFile);
eventsEmitter.on('end', endoffile);

eventsEmitter.emit('read','foo.txt');
//eventsEmitter.emit('read','JournalDEV.txt');


function readFileContent(filename){
		console.log("Reading " + filename + "started");
		fs.readFile(filename, 'utf8', readFile);
		//fs.readFile(fileName, 'utf8', readFile);
		//eventsEmitter.emit('display',data);
}

function DisplayFile(data){
	console.log(`File Data:`);
	console.log(data);
	eventsEmitter.emit('end');
	
}

function endoffile(){
  console.log("Reading and Printing File content job is done successfully.");
}


function readFile(err,data,fileName) {
    console.log("Reading " + fileName + " file done successfully.");
    eventsEmitter.emit('display',data);
}


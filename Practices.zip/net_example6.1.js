var net = require("net");
var client = net.connect('./foo.sock', function() {
console.log("Connection established");
});
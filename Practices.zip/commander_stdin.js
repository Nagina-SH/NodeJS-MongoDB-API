// var commander = require('commander');

// commander.prompt("What is your name? ", function(name) {
	// console.log('You said your name is '+ name);
	// process.stdin.pause();
// })

var commander = require("commander");
commander.confirm("Continue? ", function(proceed) {
console.log("Your response was " + proceed);
process.stdin.pause();
});
var express = require('express');

var http = require('http');

var app = express();

app.get('/', function(req, res, next) {
	res.send('Hello home page!!');
});

app.get('/foo', function(req, res, next) {
	res.send(`Hello foo page`);
})


// app.get('/products/:productId', function(req, res, next) {
	// res.send("Requested " + req.params.productId);
// });


app.get('/products/:productId(\\d+)', function(req, res, next) {
	res.send('Requested '+ req.params.productId);
})

// var server = http.createServer(app);
// server.listen(8000);

app.listen(8000);
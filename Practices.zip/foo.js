var bar= require("./bar");
console.log(bar);
console.log(`-------`);
bar_mod1();
console.log(`-------`);
bar_mod2();
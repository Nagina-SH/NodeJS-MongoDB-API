var path = require("path");
var directories = ["foo", "bar", "baz"];
var directory = directories.join(path.sep);
console.log(directory);

console.log(process.env.PATH);
console.log(`path.delimiter` , path.delimiter);
console.log('---------------------');

process.env.PATH.split(path.delimiter).forEach(function(dir) {
console.log(dir);
});

console.log('---------------------');

process.env.PATH.split("\\").forEach(function(dir) {
console.log(dir);
});
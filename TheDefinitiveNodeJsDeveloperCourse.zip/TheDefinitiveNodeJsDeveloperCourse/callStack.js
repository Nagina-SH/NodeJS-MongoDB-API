function message(){
	console.log('message');
}
message()

setTimeout(function() {
	console.log('function 1');
}, 5);

setTimeout(function() {
	console.log('function 2');
}, 3);

setTimeout(function() {
	console.log('function 3');
}, 4);

console.log('End of File');
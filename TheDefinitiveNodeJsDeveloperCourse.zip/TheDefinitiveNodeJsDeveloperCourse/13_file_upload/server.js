const express = require('express');
const hbs = require('express-handlebars');
const bodyParser = require('body-parser');
const multer = require('multer');
const port = process.env.PORT || 3000;
const path = require('path');

const app = express();

////######### HBS SETUP ############/////
app.engine('hbs', hbs({
    extname: 'hbs',
    defaultLayout: 'main',
    layoutsDir: __dirname + '/views/layouts/'
}));
app.set('view engine', 'hbs');

app.use(bodyParser.json());

// GET
app.get('/', (req, res) => {
    res.render('home')
});

const storage = multer.diskStorage({
	destination:(req, res, cb)=>{
		cb(null, 'uploads/')
	},
	filename:(req, file, cb)=>{
		cb(null, `${file.fieldname}_${Date.now()}_${file.originalname}`)
	}
})

app.post('/api/uploads',(req, res) =>{
    
const upload = multer({
		//dest: 'uploads/',
		storage: storage,
		limits: {fileSize:500000000},
		fileFilter:(req, file, cb)=>{
			const ext = path.extname(file.originalname)
			console.log(ext)
			if(ext !== '.jpg'){
				return cb(res.end('Only jpg allowed'), false);
			}
			
			cb(null, true)
		}

		}).fields([
		{name:'image', maxCount:2},
		{name:'image2', maxCount:10}
		])
	
	upload(req, res, function(err){
			console.log(`err`, err)	
		if(err){
			return res.end('only images are allowed')
		}
		res.end('File uploded')
	})
	
	//res.status(200).send('ok');
})


app.listen(port,()=>{
    console.log(`Started on port ${port}`)
});
const os = require('os');

const user = os.platform();

console.log(user);

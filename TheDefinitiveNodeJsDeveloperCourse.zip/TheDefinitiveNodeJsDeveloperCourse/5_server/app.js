const http = require('http');
const fs = require('fs');


const server = http.createServer((req, res) => {
	res.writeHead(200, {'Content-Type' : 'application/json'});
	
	const names = ["Shailendra","Ram","Shyam"];
	const cars = {
		name: "Ford",
		model:"Fiesta"
	};
	const json = JSON.stringify({
		names : names,
		cars : cars
	})
	
	res.end(json );
	
})


// const server = http.createServer((req, res) => {
	// res.writeHead(200, {'Content-Type' : 'text/html'});
	// let HTML = fs.readFileSync(`${__dirname}/index.html`)
	// res.end(HTML);
// })

// console.log(__dirname);

// const server = http.createServer((req, res) => {
	// res.writeHead(200, {'Content-Type' : 'text/html'});
	// res.write(`
		// <html>
			// <body>
				// <h1 style="background:red"> Hello there <h1>
			// </body>
		// </html>
	// `)
	// res.end();
// })

server.listen(8080, '127.0.0.1');
console.log('server is running');
const bcrypt = require('bcryptjs');
const {MD5} = require('crypto-js');


// bcrypt.genSalt(10, (err, salt)=>{
	// if(err) return next (err);
	
	// bcrypt.hash('password123', salt, (err, hash)=>{
		// if(err) return next (err);
		// console.log(hash);
	// })
	
	
// })

var user = {
	id: 1,
	token: MD5('password123').toString()
}

console.log(user);
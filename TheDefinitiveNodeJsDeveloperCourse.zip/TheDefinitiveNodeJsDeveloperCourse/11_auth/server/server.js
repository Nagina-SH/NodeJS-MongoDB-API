const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const app = express();

const port = process.env.PORT || 3000;

// DB Connection

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/auth')


const {User} = require('./models/user');
const {auth} = require('./middleware/auth');
app.use(bodyParser.json());

// POST

app.post('/api/user', (req, res)=>{
	
	const user = new User({
		email: req.body.email,
		password:req.body.password
	});
	
	user.save((err, doc)=>{
		if(err) res.status(400).send(err);
		user.generateToken((err, user)=>{
			if(err) res.status(400).send(err);
			res.header('x-token', user.token).send(user)
		})
	})
})


app.post('/api/user/login', (req, res)=>{
	//console.log(`req.body.email`, req.body.email);
	User.findOne({'email': req.body.email}, (err, user)=>{
		if(!user) res.json({message: 'Auth failed. User not found'});
		
		user.comparePassword(req.body.password, function(err, isMatch){
			//console.log(`req.body.password`, req.body.password);
			if(err) throw err;
			if(!isMatch) return res.json({message: "Wrong Passord"});
			
			//res.status(200).send(isMatch);
			
			user.generateToken((err, user)=>{
				if(err) throw err;
				res.header('x-token', user.token).send(user)
			})
		})
		
	})
})


app.get('/user/profile',auth, (req, res)=> {
	res.status(200).send(req.user);
})


app.delete('/user/delete',auth, (req, res)=> {
	//res.status(200).send(req.user);
	
	req.user.deleteToken(req.token, (err,user)=>{
		if(err) res.status(400).send(err);
		res.status(200).send()	
	})
})

app.listen(port, ()=>{
	console.log(`Started on port ${port}`);
})
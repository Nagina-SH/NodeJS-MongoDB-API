const events = require('events');
const evenEmitter = new events.EventEmitter();

const ringBell = ()=> {
	console.log('ring ring ring');
}

const sayHello = ()=> {
	console.log('Hello, Who is there!!!');
}

const Iam = function(){
	console.log('I am Mike');
}

evenEmitter.on('guestHere', ringBell);
evenEmitter.on('guestHere', sayHello);
evenEmitter.on('guestHere', Iam);

evenEmitter.emit('guestHere');
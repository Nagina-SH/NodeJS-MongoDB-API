const express = require('express');
const hbs = require('express-handlebars');
const bodyParser = require('body-parser');

const app = express();

app.engine('hbs', hbs({
	extname: 'hbs',
	defaultLayout: 'layout',
	layoutsDir: __dirname + '/views/layouts/'
	}));
app.set('view engine', 'hbs');

const urlencodeParser = bodyParser.urlencoded({extended:false})
const jsonParser = bodyParser.json();

app.use("/css", express.static(__dirname + '/public/css'))

app.use('/', (req, res, next) => {
	console.log(`some made a request from: ${req.url}`);
	res.cookie("cookieName", "cookieValue")
	next();
});


app.get("/", (req, res) => {
	res.send(`
		<html>
			<head>
				<link type="text/css" rel="stylesheet" href="/css/style.css">
			</head>
		
			<body>
				<h1>My node app</h1>
			</body>
		</html>
	`)
});


app.get("/api/user", (req,res) => {
	res.send({
		name: "Node",
		lastname: "Js"
	})
})


app.get("/user", (req, res)=> {
	res.render('user', 
			{title: "Tutorials", 
			name: "Node", 
			lastname: "JS",
			vaild: true,
			pets : ['cats', 'dog', 'snake'],
			parents: [{father: "band", mother: "sarah"}]
			});
})


app.get("/api/:user/:id", (req,res) => {
	var id = req.params.id;
	var user = req.params.user;
	res.send(
	`
		<html>
			<body>
				<h1>The ${user} id is ${id}</h1>
			</body>
		</html>
	`)
})

//		/cars?brand=fors&yesr=2018
app.get("/api/cars", (req,res) => {
	var brand = req.query.brand;
	var year = req.query.year;
	res.send({
		brand: brand,
		year: year
	})
})


app.get("/enteruser", (req, res) => {
	res.render('enteruser');
})

app.post("/enteruser", urlencodeParser, (req, res) => {
	const firstname = req.body.firstname;
	const lastname = req.body.lastname;
	console.log(firstname);
	console.log(lastname);
	
})

app.get("/enteruserjson", (req, res) => {
	res.render('enteruserjson');
});

app.post("/enteruserjson", jsonParser, (req, res) => {
	const firstname = req.body.firstname;
	const lastname = req.body.lastname;
	console.log(firstname);
	console.log(lastname);
	
});

const port = process.env.PORT || 3000;

app.listen(port);
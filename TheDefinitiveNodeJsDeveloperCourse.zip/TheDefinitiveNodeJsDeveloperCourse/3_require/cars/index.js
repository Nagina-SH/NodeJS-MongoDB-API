// var brands = function(){
	// return ["Ford", "Toyato", "Tata"];
// };

// module.exports = {
	// brands : brands
// }


const brands = require('./brands');
const models = require('./models');

module.exports = {
	brands:brands.nbrands,
	models:models.models
}
module.exports = () => {
	console.log('It is NodeJS');
}
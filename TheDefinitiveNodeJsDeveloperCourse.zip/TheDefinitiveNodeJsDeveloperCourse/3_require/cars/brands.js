// var nbrands = function() {
	// return ["Ford", "Toyato", "Tata"];
// };

const json = require('./data.json');
var nbrands = function() {
	return json.brands;
};

module.exports = {
	nbrands : nbrands
}
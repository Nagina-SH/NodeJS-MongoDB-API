const json = require('./data.json');
var models = function() {
	return json.models;
};

// var models = function() {
	// return ["v2", "i20", "suv"];
// };

module.exports = {
	models : models
}
function message(){
	this.message = "Node rocks 4"
}

module.exports = new message();
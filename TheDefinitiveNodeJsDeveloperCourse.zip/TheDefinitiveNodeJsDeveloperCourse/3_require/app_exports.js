// const message = require('./message.js');
// message();
// message.message();
// console.log(message);

const {message} = require('./message2.js');

console.log(message);
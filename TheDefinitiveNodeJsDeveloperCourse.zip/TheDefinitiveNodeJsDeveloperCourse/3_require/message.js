module.exports = () => {
	console.log('It is NodeJS');
}

module.exports.message = () => {
	console.log('It is NodeJS v2.0');
}
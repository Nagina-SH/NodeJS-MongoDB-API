const cars = require('./cars');

console.log(cars.brands());
console.log(cars.models());
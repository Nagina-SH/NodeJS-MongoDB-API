const fs = require('fs');

//console.log(process.argv);

const getJson = fs.readFileSync('db.json');
const data = JSON.parse(getJson);

data.name = 'Shailendra';
data.order = 'Pizz';
const saveIt = (newData) => {
	const toString = JSON.stringify(newData);
fs.writeFileSync('db.json', toString);
}



saveIt(data);



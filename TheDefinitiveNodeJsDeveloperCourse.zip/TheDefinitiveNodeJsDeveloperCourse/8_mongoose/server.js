const mongoose = require('mongoose');

mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost:27017/App');
//create Schema
const carSchema = mongoose.Schema({
	brand: String,
	model: String,
	year: Number,
	avail: Boolean
});

// create model and link to schema
const Car = mongoose.model('Car', carSchema);

// create instance of model
const addCar = new Car({
	brand: "Ford",
	model: "Focus",
	year: "2000",
	avail:true
});

addCar.save((err, doc)=>{
	if(err){
		return console.log(err);
	}
	console.log(doc);
});


Car.findOne({brand: "Ford"}, (err, doc)=> {
	if(err){
		return console.log(err);
	}
	console.log(doc);
})



Car.findByIdAndUpdate("5aa25bb2ea775f1678646078", 
					{$set: {
						model: "Model"
					}},
					{new: true
					}
					,(err, docs)=>{
						if(err) return console.log(err);
					});
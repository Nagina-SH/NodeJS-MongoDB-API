const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const app = express();

const server = http.createServer(app)

const io = socketIO(server);

app.use(express.static(__dirname + '/../public'));

io.on('connection', (socket)=>{
	console.log('someone is connected');
	socket.on('join',(data)=>{
		console.log(data)
		
		socket.join("room-"+ data.room);
		socket.broadcast.to("room-"+ data.room).emit('newUser', `${data.user} joined the room`)
		
	})
	
	// socket.on('sendMessage', (message, cb)=>{
		// console.log('message recived form client', message);
		
		// // socket.emit('newMessage', {
			// // from: "Shailendra",
			// // message: "I am nodeJS developer"
		// // });
		// // io.emit('newMessage', {
			// // from: "Shailendra",
			// // message: "I am nodeJS developer"
		// // });
		// socket.broadcast.emit('newMessage', {
			// from: "Shailendra",
			// message: "I am nodeJS developer"
		// }, ()=>{
			// console.log('message recived')
		// });
		
		// cb()
	// })
	
	socket.on('disconnect', ()=>{
		console.log('user disconnected from server')
	})
})


const port = process.env.PORT || 3001;

server.listen(port, ()=>{
	console.log(`Server is running on ${port}`)
})
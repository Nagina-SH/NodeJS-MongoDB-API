const fs = require('fs');
const user = require('os').userInfo();
const userData = require('./user.js');

date = new Date();
const message = `user ${user.username} started app at ${date} \n`

console.log('userData.user', userData.user);
console.log('userData.addLog', userData.addLog());
//console.log(module);

if(userData.addLog()) {
fs.appendFile("hello.txt", message, (err) => {
	if(err) {
		console.log(err);
	}
	
});
}
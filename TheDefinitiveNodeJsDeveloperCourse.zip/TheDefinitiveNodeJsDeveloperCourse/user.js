const user = {
	name : 'Shailendra',
	age : '29'
};

var addLog = () => {
return true;
}
//console.log(user);

var addLog2 = function() { 
	return true;
 };


module.exports = {
	user:user,
	addLog : addLog
}
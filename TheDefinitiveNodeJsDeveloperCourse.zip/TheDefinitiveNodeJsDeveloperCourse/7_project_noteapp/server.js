const express = require('express');
const hbs = require('express-handlebars');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const fetch = require('node-fetch');
const app = express();

mongoose.connect('mongodb://localhost/noteapp');
const db = mongoose.connection;

// set routers
const addNote = require('./routes/addnote');
const note = require('./models/addnote_model');
//const customers = require('./routes/customers');

/// HBS set up ////////

app.engine('hbs', hbs({
	extname: 'hbs',
	defaultLayout: 'layout',
	layoutDir: __dirname + '/views/layouts',
	PartialsDir: __dirname + '/views/Partials'
}))

app.set('view engine', 'hbs');

// CSS

app.use("/css", express.static(__dirname + '/public/css'))

const jsonParser = bodyParser.json();

//GET

app.get('/', (req,res)=> {
	note.findNote((err, notedata) => {
		if(err){
			console.log(err);
			res.send(err);
		}
		//res.json(notedata);
		res.render('home', {
			articles : notedata
		});
	})
	//res.render('home');
})

app.get('/edit_note/:id', (req,res)=>{
	const id = req.params.id;
	console.log(id);
	note.findNoteOne(id, (err, notedata) => {
		if(err){
			console.log(err);
			res.send(err);
		}
		//res.json(notedata);
		res.render('edit_note', {
			articles : notedata
		});
	});
	})



/*
usually happens when you send several responses for one request. 
Make sure the following functions are called only once per request:
•res.json()
•res.send()
•res.redirect()
•res.render()

*/


// app.get('/', (req,res)=> {
	// res.render('home');
// })


// POST

app.use('/api/add_note', jsonParser, addNote);

// app.post('/api/add_note',jsonParser,(req,res)=>{
  // console.log(req.body);
// })

app.get('/add_note', (req,res)=> {
	res.render('add_note');
})


const port = process.env.PORT || 3000;
app.listen(port, ()=> {
	console.log(`Server up on port ${port}`);
})
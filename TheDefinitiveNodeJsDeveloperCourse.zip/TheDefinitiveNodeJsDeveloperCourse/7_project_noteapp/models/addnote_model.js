const mongoose = require('mongoose');

const noteSchema = mongoose.Schema({
	owner: {
		type: String
	},
	title: {
		type: String
	},
	message: {
		type: String
	}
})

const note = module.exports = mongoose.model('note', noteSchema);

// Add note

const addNote = function(notes, callback){
	console.log(`notes`, notes);
	const add = {
		owner: notes.owner,
		title: notes.title,
		message: notes.message
	};
	
	note.create(add, callback);
}

const findNote = function(callback, limit){
	note.find(callback).limit(limit);
}

const findNoteOne = function(id, callback){
	note.findOne({owner: id}, callback);
}

const deleteNote = function(id, callback){
	//const query = {owner, id};
	note.remove({owner : id}, callback)
}

// module.exports.removeInvoice = (id, callback) => {
	// const query = {_id, id};
	// Invoice.remove(query, callback);
// }

const updateNote =  function(id, note, options, callback) {
	const query = {owner : id};

	
	const update = {
		owner : note.owner,
		title : note.title,
		message : note.message
	};

	//note.updateOne(query, update, options, callback);
	//note.updateOne(query, {$push:update}, options, callback);
	note.updateOne({owner: 'shailendra'}, {$set:{b:2}});
}

module.exports = {
	addNote : addNote,
	findNote: findNote,
	deleteNote: deleteNote,
	findNoteOne : findNoteOne,
	updateNote : updateNote
}
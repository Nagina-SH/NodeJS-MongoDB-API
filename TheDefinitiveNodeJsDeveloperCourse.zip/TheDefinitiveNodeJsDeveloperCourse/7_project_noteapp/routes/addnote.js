const express = require('express');
const router = express.Router();

addNotes = require('../models/addnote_model');

router.post('/', (req, res) => {
	const note = req.body;
	addNotes.addNote(note, (err, note) => {
		if(err){
			console.log(err);
			res.send(err);
		}
		res.json(note);
	})
});

router.post('/view', (req, res) => {
	const note = req.body_id;
	addNotes.addNote(note, (err, note) => {
		if(err){
			console.log(err);
			res.send(err);
		}
		res.json(note);
	})
});


router.delete('/delete/:id', (req, res) => {
	//console.log(req);
	const id = req.params.id;
	//console.log(owner);
	
	addNotes.deleteNote(id, (err, note) => {
		if(err){
			res.send(err);
		}
		res.json(note);
	})
})


router.put('/update/:id', (req, res) => {
	//console.log(req);
	const id = req.params.id;
	console.log(id);
	const note = req.body;
	
	addNotes.updateNote(id, note, {}, (err, note) => {
		if(err){
			res.send(err);
		}
		res.json(note);
	})
})


// router.put('/:id', (req, res) => {
	// const id = req.params.id;
	// const invoice = req.body;
	
	// Invoice.updateInvoice(id, invoice, {}, (err, invoice) => {
		// if(err){
			// res.send(err);
		// }
		// res.json(invoice);
	// })
// })



module.exports = router;
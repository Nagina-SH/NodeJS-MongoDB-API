var winner = true;

function user(){
	var winner = false;
	console.log(winner);
}

user();
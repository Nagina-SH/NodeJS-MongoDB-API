// let superhero = new Map();

// superhero.set('Batman', {
	// realName:'Bruce Wayne',
	// power:'Millonaire',
	// weakness:'None'
// })

// superhero.set('Shailendra', {
	// realName:'Shailu',
	// power:'Hmmmmm',
	// weakness:'alot'
// })

// // superhero.forEach((value, key)=>{
	// // console.log(key)
	// // console.log(value)
// // })


// let names = Array.from(superhero.values()).map(item => {
	// return item.realName
// })

// console.log(names)

// console.log(Array.from(superhero.keys() ));
// console.log(Array.from(superhero.values() ));

// superhero.set('Trigger', ()=>{console.log('Trigger')})

// console.log(superhero.get('Trigger')());

// let mySet = new Set(['A','CB','C','D', 'CA'])

// let filtered = [...mySet].filter((item)=>{
	// return item.startsWith('C')
// })

// console.log(filtered);

// let mySet = new Set(['A','B','C','D', 'A'])

// mySet.forEach((item)=>{
	// console.log(item)
// })


// let mySet = new Set(['A','B','C','D', 'A'])

// for(let item of mySet){
	// console.log(item)
// }

// console.log(mySet)


// let mySet = new Set(['A','B','C','D'])

// mySet.add('E')
// mySet.add('E')

// console.log(mySet.has('E'))

// mySet.delete('A')

// console.log(mySet)

// console.log(mySet.size)


// mySet.clear();
// console.log(mySet)


// import { sum } from './app.js'

// console.log(sum)

// console.log(Math.trunc(42.8))
// console.log(Math.trunc(0.8))
// console.log(Math.trunc(-0.1))

// var word = "camera";
// console.log(word.includes("cam") )
//console.log(word.endsWith("a",2) )
//console.log(word.startsWith("cadsm") )

//console.log("foo".repeat(3*10))


// const url = 'https://jsonplaceholder.typicode.com/posts/100';

// //console.log(fetch(url))

// // fetch(url, {
	// // method: 'POST',
	// // headers: {
		// // 'Content-Type' : 'application/json'
	// // },
	// // body: JSON.stringify({title:'some dum title'})
// // })
// fetch(url, {
	// method: 'GET'
// })
// .then(response => response.json())
// .then((data)=>{console.log(data)})
// .catch((error)=>{console.log(error)})




// let promise = new Promise((resolved, rejected)=>{
	// setTimeout(()=>{
		// rejected();
	// }, 3000)
// })



// promise
// .then(()=>{console.log('finished') })
// .then(()=>{console.log('finished 2')} )
// .catch( ()=>{console.log('damn') })

// function createCar({type,model,brand, color,year}){
 // console.log(brand, color, year, type);
// }

// const car = {
	// brand: "ford",
	// model:"focus",
	// color: "red",
	// year: "2015"
// }

// createCar(car)

// const users = {
	// names: ['ABC','CDF','GHI']
// }

// const {names:[pos1, pos2]} = users;

// console.log(pos2);


// const users = [
	// {name:"Francis", lastname:"Jones", age:25},
	// {name:"martha", lastname:"Smith", age:29},
	// {name:"Helen", lastname:"Joe", age:30}
// ];

// const [{lastname},{name}, {age}] = users;

// console.log(lastname, name, age)

// const cars = [
	// 'camaro',
	// 'nova',
	// 'A4'
// ];

// const [camaro,...rest] = cars;

// console.log(rest);




// class Car {
	// constructor(){
		// this.status = 'New'
		// this.wheels = 4
		// this.avail = ()=>{
			// console.log('avail')
		// }
		
	// }
// }

// class Ford extends Car{
	// constructor(){
		// super()
	// }
// }

// const car = new Car();
// const ford = new Ford();

// ford.color = 'red';
// console.log(ford)

// class Car{
	// constructor(options){
		// this.status = options.status;
		// this.wheels = options.wheels;
		// this.avail = options.avail;
	// }
// }

// const car = new Car({
	// status:'New',
	// wheels:4,
	// avail: ()=>{
		// console.log('available')
	// }
// })

// console.log(car);

// class Car{
	// constructor(){
		// this.status = 'New';
		// this.wheels = 4;
		// this.avail = ()=>{
			// console.log('Available')
		// }
	// }
// }

// const car = new Car();
// const ford = new Car();

// ford.color = 'red';

// console.log(ford.avail());
//console.log(car);

// function Car(){}

// var car = new Car();

// Car.prototype.status = 'New';
// Car.prototype.wheels = 4;
// Car.prototype.status = function(){
	// console.log('available');
// }

// var ford = new Car();

// //console.log(car);
// //console.log(car.__proto__);

// console.log(ford.__proto__);

// var ul = document.querySelector('.user_list')

// const cars = [
// {brand:"Ford", price:600, available:2,type:"Sport car"},
// {brand:"Nissan", price:250, available:2,type:"Sport car"},
// {brand:"Ford", price:90, available:2,type:"Wagon"},
// {brand:"Ford", price:300, available:2,type:"Urbon"},
// ]

// function getResults(price, type){
	// return cars.find(function(car){
		// console.log(car)
		// return car.price < price && car.type === type
	// })
// }





// document.querySelector('.search').addEventListener("click", function(){
	// let price = parseInt(document.querySelector('#price').value)
	// let type = document.querySelector('#type').value
	
	// // console.log(price)
	// // console.log(type)
	
	// let list = '';
	
	// let results = getResults(price, type)
	// //console.log(results)
	// list += `<li>${results.brand} - ${results.type}<li>`
	// ul.insertAdjacentHTML("beforeend", list)
// })



// const channel = [
   // {name:'HBO',premium:true},
   // {name:'LIFE',premium:false},
   // {name:'Max',premium:true},
   // {name:'Cooking channel',premium:false},
   // {name:'HBO',premium:false}
// ];

// const result = channel.find(function(item){
	// return item.name === 'HBO'
// })

// console.log(result)

// const channel = [
   // {name:'HBO',premium:true},
   // {name:'LIFE',premium:false},
   // {name:'Max',premium:true},
   // {name:'Cooking channel',premium:false},
   // {name:'WOBI',premium:false}
// ];
// const user = {
   // name:'Francis',
    // premium:true,
    // premiumChannels:function(){
		// const $this = this
        // return channel.filter(function(item){
			// return item.premium === true && $this.premium;
		// })
    // },
    // channels:function(){
        // return channel.filter(function(item){
			// return item.premium === false;
		// })
    // }
 // }
 // console.log(user.premiumChannels())
 // // brings HBO and MAX
 // console.log(user.channels())
 // // brings LIFE, COOCKING CHANNEL AND WOBI


// const channels = [
   // {name:'HBO',premium:true},
   // {name:'LIFE',premium:false},
   // {name:'Max',premium:true},
   // {name:'Cooking channel',premium:false},
   // {name:'WOBI',premium:false}
// ];

// const result = channels.filter(function(item){
	// return item.premium
// })

// console.log(result)

// const paintings = [
   // {name:'Mona lisa',width:200,height:200},
   // {name:'The scream',width:400,height:600},
   // {name:'The scream',width:300,height:600},
   // {name:'The last supper',width:600,height:700}
// ];


// const result = paintings.filter(function(item){
	// return item.height === 600 && item.width === 300
// })

// console.log(result)


// const paintings = [
   // {name:'Mona lisa',width:200,height:200},
   // {name:'The scream',width:400,height:600},
   // {name:'The last supper',width:600,height:700}
// ];

// const otherArray = paintings.map(function(item){
	// return `The ${item.name} is ${item.width} x ${item.height}`;
// })

// otherArray.forEach(function(name){
	// console.log(name);
// })

// const users = [
	// {user:'Martin', age:32, eyes:'brown'},
	// {user:'Jon', age:32, eyes:'Red'},
	// {user:'Brain', age:32, eyes:'blue'}
// ];

// const listOfUsers = users.map(function(user){
	// return user.user
// })

// listOfUsers.forEach(function(name){
	// const select = document.querySelector('select')
	// console.log(name)
	// select.insertAdjacentHTML("afterbegin", `<option value="${name}"> ${name}</option>`)
// })


// const numbers = [1,2,3,4];

// const otherArray = numbers.map(function(number){
	// return number * 10;
// })

// console.log(otherArray);

//var numbers = [1,2,3,4,5];

//var otherArray = [];

// for(i=0; i< numbers.length; i++){
	// otherArray.push(numbers[i]*10)
// }

//console.log(otherArray);


// var ul = document.querySelector('.product');

// var products = [
    // {name:'Iphone',price:200},
    // {name:'Motorola',price:70},
    // {name:'Samsung',price:150},
    // {name:'Sony',price:98},
    // {name:'Windows pone',price:10}
 // ];


 
// let list = '';




// products.forEach(function(item){
	// //console.log(item)
	// //list += `<li>${item.name} - ${item.price}<li>`
	
// function discount(){
	// if(item.price < 100){
		// return `<span> On sale !!</span>`
	// }
// }	
	
	// list += `
		// <div class="product">
			// <h1>${item.name}</h1>
			// ${discount()}
			// <strong>Price: $${item.price} </strong>
		// </div>	` ;
// })

// document.body.insertAdjacentHTML("afterbegin", list)

//ul.insertAdjacentHTML("afterbegin", list)
 
 
// const artists = ['A','B','C','D'];

// artists.forEach(function(item){
	// console.log(item);
// })


// var ul = document.querySelector('.user_list')

// const players = [
	// {name:"shailendra", lastname:"Nagina"},
	// {name:"Rama", lastname:"Nagina"}
// ] ;


// let list = '';

// for(i=0; i< players.length; i++){
	// let player = players[i]
	
// list += `<li>${player.name} - ${player.lastname}<li>`
// }

// ul.insertAdjacentHTML("beforeend", list)



// function adduser(name, lastname){
	// var template = '';
	
	// template += `
		// <div class="user">
			// <div>${name}</div>
			// <div>${lastname}</div>
		// </div>` ;
		
		// list.insertAdjacentHTML("beforeend", template)
// }


// adduser('shailendra', 'nagina');
// adduser('RK', 'nagina');











// var divs = document.getElementsByTagName('div');
// // for(var i=0; i < divs.length; i++){
// for(let i=0; i < divs.length; i++){

	// divs[i].addEventListener('click', function(){
		// console.log('you clicked div #' + i)
	// })
	
// }

// function request(page, id){
	// const URL = `http://server.com/${page}/${id}`;
	// console.log(URL)
// }

// request('pages',5)


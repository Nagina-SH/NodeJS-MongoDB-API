function returnEmployee(){
	const name = 'Francis';
	const age = 21;
	const position = 'Manager';
	
	console.log('His name is ');
}

returnEmployee();
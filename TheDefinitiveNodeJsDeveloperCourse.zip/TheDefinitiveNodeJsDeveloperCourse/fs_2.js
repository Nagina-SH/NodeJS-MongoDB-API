const fs = require('fs');

// Blocking
// const data = fs.readFileSync('./file.txt', 'utf8');
// console.log(data);

// Non-blocking
const data = fs.readFile('./file.txt', 'utf8', (err,data) => {
	if(err) throw err;
	console.log(data);
})


function showMessage(){
	console.log('finished');
}

showMessage();
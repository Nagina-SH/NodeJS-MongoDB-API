db.currentOp()
{
        "inprog" : [
                {
                        "desc" : "conn2",
                        "threadId" : "5280",
                        "connectionId" : 2,
                        "client" : "127.0.0.1:52056",
                        "active" : true,
                        "opid" : 45197,
                        "secs_running" : 0,
                        "microsecs_running" : NumberLong(28),
                        "op" : "command",
                        "ns" : "admin.$cmd",
                        "query" : {
                                "currentOp" : 1
                        },
                        "numYields" : 0,
                        "locks" : {

                        },
                        "waitingForLock" : false,
                        "lockStats" : {

                        }
                }
        ],
        "ok" : 1
}

db.currentOp( { "$ownOps": true } )
{ "inprog" : [ ], "ok" : 1 }
db.currentOp( { "$ownOps": true }, { "$all": true })
{ "inprog" : [ ], "ok" : 1 }

db.currentOp( { "$ownOps": true }, { "$all": true })
{ "inprog" : [ ], "ok" : 1 }

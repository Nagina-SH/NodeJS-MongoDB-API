db.printSlaveReplicationInfo()
local.sources is empty; is this db a --slave?

db.cloneCollection(from, collection, query)

Copies data directly between MongoDB instances. The db.cloneCollection() method wraps the cloneCollection database command and accepts the following arguments:

from string The address of the server to clone from. 

use users
db.cloneCollection('127.0.0.1:52056', 'profiles',
                    { 'active' : true } )
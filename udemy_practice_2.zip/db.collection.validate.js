db.collection.validate()

db.students.validate()

db.students.validate()
{
        "ns" : "test.students",
        "datasize" : 336,
        "nrecords" : 3,
        "lastExtentSize" : 8192,
        "firstExtent" : "0:201000 ns:test.students",
        "lastExtent" : "0:201000 ns:test.students",
        "extentCount" : 1,
        "firstExtentDetails" : {
                "loc" : "0:201000",
                "xnext" : "null",
                "xprev" : "null",
                "nsdiag" : "test.students",
                "size" : 8192,
                "firstRecord" : "0:2010b0",
                "lastRecord" : "0:2011b0"
        },
        "deletedCount" : 1,
        "deletedSize" : 7632,
        "nIndexes" : 2,
        "keysPerIndex" : {
                "test.students.$_id_" : 3,
                "test.students.$score_1" : 5
        },
        "valid" : true,
        "errors" : [ ],
        "warning" : "Some checks omitted for speed. use {full:true} option to do more thorough scan.",
        "ok" : 1
}


db.students.validate(true)
{
        "ns" : "test.students",
        "datasize" : 336,
        "nrecords" : 3,
        "lastExtentSize" : 8192,
        "firstExtent" : "0:201000 ns:test.students",
        "lastExtent" : "0:201000 ns:test.students",
        "extentCount" : 1,
        "extents" : [
                {
                        "loc" : "0:201000",
                        "xnext" : "null",
                        "xprev" : "null",
                        "nsdiag" : "test.students",
                        "size" : 8192,
                        "firstRecord" : "0:2010b0",
                        "lastRecord" : "0:2011b0"
                }
        ],
        "firstExtentDetails" : {
                "loc" : "0:201000",
                "xnext" : "null",
                "xprev" : "null",
                "nsdiag" : "test.students",
                "size" : 8192,
                "firstRecord" : "0:2010b0",
                "lastRecord" : "0:2011b0"
        },
        "objectsFound" : 3,
        "invalidObjects" : 0,
        "nQuantizedSize" : 3,
        "bytesWithHeaders" : 384,
        "bytesWithoutHeaders" : 336,
        "bytesBson" : 156,
        "deletedCount" : 1,
        "deletedSize" : 7632,
        "delBucketSizes" : [
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0
        ],
        "nIndexes" : 2,
        "keysPerIndex" : {
                "test.students.$_id_" : 3,
                "test.students.$score_1" : 5
        },
        "indexDetails" : {
                "test.students.$_id_" : {

                },
                "test.students.$score_1" : {

                }
        },
        "valid" : true,
        "errors" : [ ],
        "ok" : 1
}


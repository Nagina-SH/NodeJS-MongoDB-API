cursor.batchSize


// The following example sets the batch size for the results of a query (i.e. find()) to 10. The batchSize() method does not change the output in the mongo shell, which, by default, iterates over the first 20 documents.

db.people.find()
db.people.find().batchSize(10)
db.people.find().batchSize(10).count()

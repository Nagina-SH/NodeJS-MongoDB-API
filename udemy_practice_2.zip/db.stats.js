db.stats(1024)
{
        "db" : "test",
        "collections" : 24,
        "objects" : 197,
        "avgObjSize" : 129.54314720812184,
        "dataSize" : 24.921875,
        "storageSize" : 188,
        "numExtents" : 24,
        "indexes" : 29,
        "indexSize" : 231.546875,
        "fileSize" : 65536,
        "nsSizeMB" : 16,
        "extentFreeList" : {
                "num" : 0,
                "totalSize" : 0
        },
        "dataFileVersion" : {
                "major" : 4,
                "minor" : 22
        },
        "ok" : 1
}

db.collection.getShardVersion()

db.students.getShardVersion()

db.students.getShardDistribution()
Collection test.students is not sharded.
db.students.getShardVersion()
{
        "configServer" : "",
        "global" : Timestamp(0, 0),
        "inShardedMode" : false,
        "mine" : Timestamp(0, 0),
        "ok" : 1
}

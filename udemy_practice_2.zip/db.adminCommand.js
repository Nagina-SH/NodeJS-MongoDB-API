db.adminCommand

db.adminCommand(
  {
    createUser: "bruce",
    pwd: "bruce123",
    roles: [
      { role: "dbOwner", db: "admin" }
    ]
  }
)
{ "ok" : 1 }



use admin
switched to db admin



show users
{
        "_id" : "admin.bruce",
        "user" : "bruce",
        "db" : "admin",
        "roles" : [
                {
                        "role" : "dbOwner",
                        "db" : "admin"
                }
        ]
}
db.orders.aggregate([
                     { $match: { status: "A" } },
                     { $group: { _id: "$cust_id", total: { $sum: "$amount" } } },
                     { $sort: { total: -1 } }
                   ])


db.people.aggregate(
   [
      { $group: { _id: "$name", count: { $sum: "$age" } } }
   ]
)

db.people.aggregate(
   [
      { $group: { _id: "$name", count: { $sum: "$age" } } }
   ]
).count()
cursor.pretty


db.collection.find(<query>).pretty()


db.people.find({}).pretty()

{
        "_id" : ObjectId("5a3a08645900ab4e384292bf"),
        "name" : "Joe Update",
        "age" : 70
}
{
        "_id" : ObjectId("5a3a08645900ab4e384292c0"),
        "name" : "Joe Update",
        "age" : 71
}
{
        "_id" : ObjectId("5a3b7cdefdd819ddfda34c06"),
        "name" : "UpdateOne",
        "Lname" : "Nagina"
}
{
        "_id" : ObjectId("5a3b80740d6ae3774568a313"),
        "name" : "Sally",
        "age" : undefined
}
{
        "_id" : ObjectId("5a42201f664856b52a175fc8"),
        "name" : "UpdateOne",
        "Lname" : "Nagina"
}



db.students.find({}).pretty()
{ "_id" : 1, "score" : [ -1, 3 ] }
{ "_id" : 2, "score" : [ 1, 5 ] }
{ "_id" : 3, "score" : [ 5, 5 ] }
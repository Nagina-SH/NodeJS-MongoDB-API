db.characters.find()
{ "_id" : 4, "char" : "Dithras", "class" : "barbarian", "lvl" : 4 }
{ "_id" : 5, "char" : "Taeln", "class" : "fighter", "lvl" : 3 }


db.characters.find({"lvl" : {3} })
db.characters.find({"lvl" : {$gt : 2}})

db.characters.find({"lvl" : {$gt : 2}}).count()

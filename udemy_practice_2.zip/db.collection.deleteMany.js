db.collection.deleteMany

db.orders.insert([
{ "_id" : 6, "cust_id" : "xyz1", "ord_date" : ISODate("2013-10-01T17:04:11.102Z"), "status" : "A", "amount" : 100 },
{ "_id" : 7, "cust_id" : "xyz1", "ord_date" : ISODate("2013-10-12T17:04:11.102Z"), "status" : "D", "amount" : 25 },
{ "_id" : 8, "cust_id" : "xyz1", "ord_date" : ISODate("2013-10-11T17:04:11.102Z"), "status" : "D", "amount" : 125 },
{ "_id" : 14, "cust_id" : "abc1", "ord_date" : ISODate("2014-11-12T17:04:11.102Z"), "status" : "A", "amount" : 25 },
{ "_id" : 10, "cust_id" : "xyz1", "ord_date" : ISODate("2015-10-01T17:04:11.102Z"), "status" : "A", "amount" : 100 },
{ "_id" : 11, "cust_id" : "xyz1", "ord_date" : ISODate("2016-10-12T17:04:11.102Z"), "status" : "D", "amount" : 25 },
{ "_id" : 12, "cust_id" : "xyz1", "ord_date" : ISODate("2010-10-11T17:04:11.102Z"), "status" : "D", "amount" : 125 },
{ "_id" : 15, "cust_id" : "abc1", "ord_date" : ISODate("2011-11-12T17:04:11.102Z"), "status" : "A", "amount" : 25 }

])


db.orders.deleteMany({"cust_id" : "xyz1"});

db.orders.find().count();
db.orders.find().sort({"_id" : 1});
db.orders.find().sort({"_id" : 1});

db.orders.deleteMany( { "cust_id" : "xyz1", "amount" : { $gt : 110 } } );


try {
   db.orders.deleteMany(
       { "cust_id" : "xyz1", "amount" : 100 },
       { w : "majority", wtimeout : 100 }
   );
} catch (e) {
   print (e);
}

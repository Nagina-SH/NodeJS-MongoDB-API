db.getSiblingDB

//Used to return another database without modifying the db variable in the shell environment.

db = db.getSiblingDB('admin')
db.system.version.find()

use test
switched to db test
db = db.getSiblingDB('admin')
db.system.version.find()admin

{ "_id" : "authSchema", "currentVersion" : 5 }

// Example

users = db.getSiblingDB('users')
records = db.getSiblingDB('records')

users.active.count()
users.active.findOne()

records.requests.count()
records.requests.findOne()

// This operation creates two db objects referring to different databases (i.e. users and records) and then returns a count and an example document from one collection in that database (i.e. active and requests respectively.)
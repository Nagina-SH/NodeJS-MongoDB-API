db.collection.createIndexes

db.myColl.createIndex(
{category : -1},
	{status : -1}
)
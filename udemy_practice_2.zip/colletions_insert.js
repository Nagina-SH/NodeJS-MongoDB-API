db.replace_col.insert({
"name" : "joe",
"friends" : 32,
"enemies" : 2
});



db.people.insert([
{"name" : "joe", "age" : 65},
{"name" : "joe", "age" : 70},
{"name" : "joe", "age" : 71},
]);



joe = db.people.findOne({"name" : "joe", age : 70});
joe.age++;
db.people.update({"name" : "joe"}, joe);


db.users.insert(
{"comments" :
						{	"name" : "Nagina", 
							"email" : "Nagina@example.com",
							"content" : "good blog.",
							"votes" : 0
					    }
			}
)

db.users.update({"_id" : ObjectId("5a38b996708eeadfc873bbe5")},
 {"$set" : {"favorite book" : "War and Peace"}});
 
 
 db.users.update({"_id" : ObjectId("5a38b996708eeadfc873bbe5")}, {"$set" : {"favorite book" : "War and Peace"} })
 
 
 db.users.update({"name" : "joe"},
 {"$set" : {"favorite book" : "Green Eggs and Ham"}})
 
 
  db.users.update({"name" : "joe"},
 {"$set" : {"favorite book" : ["Cat's Cradle", "Foundation Trilogy", "Ender's Game"]}})
 
 // remove data from end of array
db.users.update({}, {"$pull" : {"favorite book" : "Foundation Trilogy" }}) 


db.foo.update({"_id" : 6}, {$set: {"x" : "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD"}}, true)

db.processes.insert([{"x" : "DDDDD", "y" : "2"}]);

db.foo.insert({"x" : "DDDDD", "y": "3"});

db.foo.insert({"x" : "DDDDD", "y": "4"});

db.foo.insert({"x" : "DDDDD", "y": "5"});

db.foo.insert({"x" : "DDDDD", "y": "6"});

db.foo.insert({"x" : "DDDDD", "y": "7"});
 
 db.users.update({"name" : "joe"},
 {"$unset" : {"favorite book" : 1}})
 
 
  db.users.update({"name" : "joe"},
 {"$set" : {"favorite book" : {
	 "name" : "joe",
	 "email" : "joe@example.com"
	}
 }})
 

db.foo.update({"_id" : 5},
 {"$push" : {"comments" :
						{	"name" : "Shailendra", 
							"email" : "Shailendra@example.com",
							"content" : "good blog.",
							"votes" : 2
					    }
			}
 }
 )


 db.foo.remove({"_id" : 1})
 
 
 db.foo.insert({"_id" : 5, 
"comments" :[
						{	"name" : "Nagina", 
							"email" : "Nagina@example.com",
							"content" : "good blog.",
							"votes" : 0
					    }

			]
})

db.foo.update({"_id" : 5}, {"$inc" : {"comments.0.votes" : 1} })

db.foo.update({"x" : "DDDDD"}, {"$set" : {"gift" : "HBD"} }, false, true)
 
db.collection.insert([
{ "_id": "apples", "qty": 5 },
{ "_id": "bananas", "qty": 7 },
{ "_id": "oranges", "qty": { "in stock": 8, "ordered": 12 } },
{ "_id": "avocados", "qty": "fourteen" }
]);
 
db.collection.find({
	gty: { $gt: 4} 
}); 


db.bios.find(
   {
      _id: { $in: [ 5,  ObjectId("51e062189c6ae665454e301d") ] }
   }
) 


db.users.find({}, {"_id" : 0, "name" : 1, "sex" : 1})



db.processes.insert([
{"status" : "RUNNING", "priority" : 2},
{"status" : "READY", "priority" : 2},
{"status" : "READY", "priority" : 1},
{"status" : "READY", "priority" : 3},
{"status" : "DONE", "priority" : 1},
{"status" : "RUNNING", "priority" : 3},

])
var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { status: "P", item: null } ).upsert().updateOne(
   {
     $setOnInsert: { defaultQty: 0, inStock: true },
     $currentDate: { lastModified: true },
     $set: { points: "0" }
   }
);
bulk.execute();


var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { item: "abc1234" } ).upsert().replaceOne(
   {
     item: "abc123",
     status: "P",
     points: 200,
   }
);
bulk.execute();
db.items.find()


var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { item: "abc1234" } ).upsert().replaceOne(
   {
     item: "abc1234",
     status: "Up",
     points: 300,
   }
);
bulk.execute();
db.items.find()













var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { status: "P" } ).upsert().updateOne(
   {
     item: "TBD",
     points: 0,
     inStock: true,
     status: "I"
   }
);
bulk.execute();


var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { status: "P", item: "abc123" } ).upsert().updateOne(
   {
     $setOnInsert: { defaultQty: 1, inStock: true },
     $currentDate: { lastModified: true },
     $set: { points: "10000" }
   }
);
bulk.execute();



var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { status: "X", item: null } ).upsert().updateOne(
   {
     $setOnInsert: { defaultQty: 0, inStock: true },
     $currentDate: { lastModified: true },
     $set: { points: "0" }
   }
);
bulk.execute();

db.items.find()



db.items.find()
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc2"), "item" : "efg123", "status" : "UA", "defaultQty" : 100, "points" : "400" }
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc3"), "item" : "TBD", "points" : 0, "inStock" : true, "status" : "I" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd5"), "item" : "efg123", "status" : "UA", "defaultQty" : 100, "points" : "400" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd6"), "item" : "abc123", "status" : "P", "points" : "10000", "lastModified" : ISODate("2018-01-02T10:05:05.327Z") }
{ "_id" : ObjectId("5a4b5610dcf16f681d6fe514"), "item" : null, "status" : "P", "defaultQty" : 0, "inStock" : true, "lastModified" : ISODate("2018-01-02T09:58:29.326Z"), "points" : "0" }
{ "_id" : ObjectId("5a4b56d3dcf16f681d6fe515"), "item" : "abc123", "status" : "P", "points" : 200 }
{ "_id" : ObjectId("5a4b573ddcf16f681d6fe516"), "item" : "abc1234", "status" : "Up", "points" : 300 }
{ "_id" : ObjectId("5a4b5a20dcf16f681d6fe517"), "item" : null, "status" : "X", "defaultQty" : 0, "inStock" : true, "lastModified" : ISODate("2018-01-02T10:08:32.293Z"), "points" : "0" }



var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { status: "X" } ).upsert().update(
   {
     $setOnInsert: { defaultQty: 0, inStock: true },
     $currentDate: { lastModified: true },
     $set: { status: "I", points: "0", item: "UPSERT" }
   }
);
bulk.execute();

var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { status: "Y" } ).upsert().update(
   {
     $setOnInsert: { defaultQty: 0, inStock: true },
     $currentDate: { lastModified: true },
     $set: { status: "I", points: "0", item: "UPSERT" }
   }
);
bulk.execute();

db.items.find(
)
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc2"), "item" : "efg123", "status" : "UA", "defaultQty" : 100, "points" : "400" }
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc3"), "item" : "TBD", "points" : 0, "inStock" : true, "status" : "I" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd5"), "item" : "efg123", "status" : "UA", "defaultQty" : 100, "points" : "400" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd6"), "item" : "abc123", "status" : "P", "points" : "10000", "lastModified" : ISODate("2018-01-02T10:05:05.327Z") }
{ "_id" : ObjectId("5a4b5610dcf16f681d6fe514"), "item" : null, "status" : "P", "defaultQty" : 0, "inStock" : true, "lastModified" : ISODate("2018-01-02T09:58:29.326Z"), "points" : "0" }
{ "_id" : ObjectId("5a4b56d3dcf16f681d6fe515"), "item" : "abc123", "status" : "P", "points" : 200 }
{ "_id" : ObjectId("5a4b573ddcf16f681d6fe516"), "item" : "abc1234", "status" : "Up", "points" : 300 }
{ "_id" : ObjectId("5a4b5a20dcf16f681d6fe517"), "item" : "UPSERT", "status" : "I", "defaultQty" : 0, "inStock" : true, "lastModified" : ISODate("2018-01-02T10:16:31.544Z"), "points" : "0" }
{ "_id" : ObjectId("5a4b5c62dcf16f681d6fe518"), "status" : "I", "defaultQty" : 0, "inStock" : true, "lastModified" : ISODate("2018-01-02T10:18:10.827Z"), "points" : "0", "item" : "UPSERT" }

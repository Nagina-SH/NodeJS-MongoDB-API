db.students.find()

var t = db.students;
var cursor = db.students.find().addOption(DBQuery.Option.tailable).addOption(DBQuery.Option.awaitData);
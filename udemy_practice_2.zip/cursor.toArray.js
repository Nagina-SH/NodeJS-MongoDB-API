cursor.toArray

var allProductsArray = db.people.find({}, {name : 1}).toArray();

if (allProductsArray.length > 0) { printjson (allProductsArray[0]); }


var allProductsArray = db.people.find({}, {name : 1}).toArray();

if (allProductsArray.length > 0) { printjson (allProductsArray[0]); }
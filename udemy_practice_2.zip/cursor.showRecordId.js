cursor.showRecordId


db.students.find().showRecordId()
{ "_id" : 1, "score" : [ -1, 3 ], "$recordId" : NumberLong(3051696) }
{ "_id" : 2, "score" : [ 1, 5 ], "$recordId" : NumberLong(3051824) }
{ "_id" : 3, "score" : [ 5, 5 ], "$recordId" : NumberLong(3051952) }

db.students.find( {  }, { $recordId: 1 } ).showRecordId()

db.students.find( {  }, { $recordId: 1 } ).showRecordId()
{ "_id" : 1, "$recordId" : NumberLong(3051696) }
{ "_id" : 2, "$recordId" : NumberLong(3051824) }
{ "_id" : 3, "$recordId" : NumberLong(3051952) }

cursor.skip

db.people.find()

db.people.find({}, {name : 1})

db.people.find({}, {name : 1}).skip(10)


db.people.find({}, {name : 1});
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe2"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe3"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe4"), "name" : "Joe Update" }
{ "_id" : 1, "name" : { "first" : "John", "last" : "Backus" } }
{ "_id" : ObjectId("51df07b094c6acd67e492f41"), "name" : { "first" : "John", "last" : "McCarthy" } }
{ "_id" : 3, "name" : { "first" : "Grace", "last" : "Hopper" } }
{ "_id" : 4, "name" : { "first" : "Kristen", "last" : "Nygaard" } }
{ "_id" : 5, "name" : { "first" : "Ole-Johan", "last" : "Dahl" } }
{ "_id" : 6, "name" : { "first" : "Guido", "last" : "van Rossum" } }
{ "_id" : ObjectId("51e062189c6ae665454e301d"), "name" : { "first" : "Dennis", "last" : "Ritchie" } }
{ "_id" : 8, "name" : { "first" : "Yukihiro", "aka" : "Matz", "last" : "Matsumoto" } }
{ "_id" : 9, "name" : { "first" : "James", "last" : "Gosling" } }
{ "_id" : 10, "name" : { "first" : "Martin", "last" : "Odersky" } }
{ "_id" : ObjectId("5a3a08645900ab4e384292be"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a3a08645900ab4e384292bf"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a3a08645900ab4e384292c0"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a3b7cdefdd819ddfda34c06"), "name" : "UpdateOne" }
{ "_id" : ObjectId("5a3b80740d6ae3774568a313"), "name" : "Sally" }
{ "_id" : ObjectId("5a42201f664856b52a175fc8"), "name" : "UpdateOne" }



db.people.find({}, {name : 1}).skip(10)
{ "_id" : 8, "name" : { "first" : "Yukihiro", "aka" : "Matz", "last" : "Matsumoto" } }
{ "_id" : 9, "name" : { "first" : "James", "last" : "Gosling" } }
{ "_id" : 10, "name" : { "first" : "Martin", "last" : "Odersky" } }
{ "_id" : ObjectId("5a3a08645900ab4e384292be"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a3a08645900ab4e384292bf"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a3a08645900ab4e384292c0"), "name" : "Joe Update" }
{ "_id" : ObjectId("5a3b7cdefdd819ddfda34c06"), "name" : "UpdateOne" }
{ "_id" : ObjectId("5a3b80740d6ae3774568a313"), "name" : "Sally" }
{ "_id" : ObjectId("5a42201f664856b52a175fc8"), "name" : "UpdateOne" }
db.people.find({}, {name : 1}).skip(10).limit(1)
{ "_id" : 8, "name" : { "first" : "Yukihiro", "aka" : "Matz", "last" : "Matsumoto" } }


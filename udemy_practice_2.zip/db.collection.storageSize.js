db.collection.storageSize

db.students.storageSize()
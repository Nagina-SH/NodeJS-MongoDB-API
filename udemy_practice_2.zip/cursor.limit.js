cursor.limit

db.people.find( {}, { name: 1 } )
db.people.find( {}, { name: 1 } ).count()
19
db.people.find( {}, { name: 1 } ).limit(10)
10

db.people.find( {}, { name: 1 } ).limit(10).count()
19

Bulk.find.updateOne

var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { item: "abc123" } ).updateOne( { $set: { status: "I", points: "200" } } );
bulk.execute();
BulkWriteResult({
        "writeErrors" : [ ],
        "writeConcernErrors" : [ ],
        "nInserted" : 0,
        "nUpserted" : 0,
        "nMatched" : 1,
        "nModified" : 1,
        "nRemoved" : 0,
        "upserted" : [ ]
})



db.items.find()
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc2"), "item" : "efg123", "status" : "A", "defaultQty" : 100, "points" : 0 }
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc3"), "item" : "abc123", "status" : "I", "points" : "200" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd5"), "item" : "efg123", "status" : "A", "defaultQty" : 100, "points" : 0 }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd6"), "item" : "abc123", "status" : "P", "points" : 100 }


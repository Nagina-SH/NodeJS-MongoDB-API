Bulk.execute

var bulk = db.items.initializeUnorderedBulkOp();
bulk.insert( { item: "efg123", status: "A", defaultQty: 100, points: 0 } );
bulk.insert( { item: "xyz123", status: "A", defaultQty: 100, points: 0 } );
bulk.execute( { w: "majority", wtimeout: 5000 } );
BulkWriteResult({
        "writeErrors" : [ ],
        "writeConcernErrors" : [ ],
        "nInserted" : 2,
        "nUpserted" : 0,
        "nMatched" : 0,
        "nModified" : 0,
        "nRemoved" : 0,
        "upserted" : [ ]
})



db.items.find()
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc2"), "item" : "efg123", "status" : "A", "defaultQty" : 100, "points" : 0 }
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc3"), "item" : "xyz123", "status" : "A", "defaultQty" : 100, "points" : 0 }


var joe = db.replace_col.findOne({"name" : "joe"});
joe.relationships = {"friends" : joe.friends, "enemies" : joe.enemies};

 joe.username = joe.name;
"joe"
 delete joe.friends;
true
 delete joe.enemies;
true
 delete joe.name;
true
 db.replace_col.update({"name" : "joe"}, joe);
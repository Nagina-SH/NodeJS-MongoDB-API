cursor.forEach

db.people.find().forEach( function(myDoc) { print( "user: " + myDoc.name ); } );
user: Joe Update
user: Joe Update
user: Joe Update
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: [object BSON]
user: Joe Update
user: Joe Update
user: Joe Update
user: UpdateOne
user: Sally
user: UpdateOne


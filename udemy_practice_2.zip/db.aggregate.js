db.aggregate

use test
switched to db test





db.getName()
test


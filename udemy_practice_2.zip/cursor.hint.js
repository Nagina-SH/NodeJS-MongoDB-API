cursor.hint

db.students.find()

db.students.createIndex( { name: 1 }) 

db.students.createIndex( { name: 1 })
{
        "createdCollectionAutomatically" : false,
        "numIndexesBefore" : 2,
        "numIndexesAfter" : 3,
        "ok" : 1
}






db.students.getIndexes()
[
        {
                "v" : 1,
                "key" : {
                        "_id" : 1
                },
                "name" : "_id_",
                "ns" : "test.students"
        },
        {
                "v" : 1,
                "key" : {
                        "score" : 1
                },
                "name" : "score_1",
                "ns" : "test.students"
        },
        {
                "v" : 1,
                "key" : {
                        "name" : 1
                },
                "name" : "name_1",
                "ns" : "test.students"
        }
]

db.students.find().hint( "score_1" )
{ "_id" : 1, "score" : [ -1, 3 ] }
{ "_id" : 2, "score" : [ 1, 5 ] }
{ "_id" : 3, "score" : [ 5, 5 ] }


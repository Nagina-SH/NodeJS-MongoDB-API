db.collection.update()


db.people.update(
   { name: "Andy" },
   {
      name: "Andy",
      rating: 1,
      score: 1
   },
   { upsert: true }
)

db.people.update({name : "Andy"}, {name: "Shailendra"})

// replace document with other one
db.people.update({name : "joe"}, {name: "Shailendra", Lname : "Nagina"}, {upsert : true})

// update document key-value with another key-value
db.people.update({name : "joe"}, {$set : {age : 80} })

db.people.update({name : "joe"}, {$set : {age : 80, DOB : 1989} })
for (var i = 0; i < 1000000; i++) {
db.tester.insert({"name": "bar", "index": i, "id": 10 - i})
 }
 
 var timeRemoves = function() {
  var start = (new Date()).getTime();
 
  db.tester.remove();
  db.findOne(); // makes sure the remove finishes before continuing
 
  var timeDiff = (new Date()).getTime() - start;
  print("Remove took: "+timeDiff+"ms");
  }
> timeRemoves()
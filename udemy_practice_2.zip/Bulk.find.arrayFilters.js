Bulk.find.arrayFilters

Bulk.find(<query>).arrayFilters([ <filter1>, ... ]).updateOne(<update>);
Bulk.find(<query>).arrayFilters([ <filter1>, ... ]).update(<update>);
db.hostInfo

db.hostInfo()
{
        "system" : {
                "currentTime" : ISODate("2017-12-29T09:27:47.985Z"),
                "hostname" : "PUNTE18301SFJ3",
                "cpuAddrSize" : 32,
                "memSizeMB" : 3476,
                "numCores" : 4,
                "cpuArch" : "x86",
                "numaEnabled" : false
        },
        "os" : {
                "type" : "Windows",
                "name" : "Microsoft Windows 7",
                "version" : "6.1 SP1 (build 7601)"
        },
        "extra" : {
                "pageSize" : NumberLong(4096)
        },
        "ok" : 1
}

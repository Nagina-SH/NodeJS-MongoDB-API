Bulk.find.update

db.items.find()
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc2"), "item" : "efg123", "status" : "A", "defaultQty" : 100, "points" : 0 }
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc3"), "item" : "abc123", "status" : "U", "points" : "300" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd5"), "item" : "efg123", "status" : "A", "defaultQty" : 100, "points" : 0 }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd6"), "item" : "abc123", "status" : "P", "points" : 100 }




var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { status: "A" } ).update( { $set: { status: "UA", points: "400" } } );
bulk.find( { item: null } ).update( { $set: { item: "TBD" } } );
bulk.execute();
BulkWriteResult({
        "writeErrors" : [ ],
        "writeConcernErrors" : [ ],
        "nInserted" : 0,
        "nUpserted" : 0,
        "nMatched" : 2,
        "nModified" : 2,
        "nRemoved" : 0,
        "upserted" : [ ]
})

db.items.find()
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc2"), "item" : "efg123", "status" : "UA", "defaultQty" : 100, "points" : "400" }
{ "_id" : ObjectId("5a4b35e9bef470abc86fbbc3"), "item" : "abc123", "status" : "U", "points" : "300" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd5"), "item" : "efg123", "status" : "UA", "defaultQty" : 100, "points" : "400" }
{ "_id" : ObjectId("5a4b5208bef470abc86fbbd6"), "item" : "abc123", "status" : "P", "points" : 100 }


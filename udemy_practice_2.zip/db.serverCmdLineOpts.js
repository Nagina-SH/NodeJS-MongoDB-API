db.serverCmdLineOpts()
{
        "argv" : [
                "C:\\Program Files\\MongoDB\\Server\\3.2\\bin\\mongod.exe",
                "--dbpath",
                "C:\\NodeJS\\MongoDB\\data\\db",
                "--storageEngine=mmapv1"
        ],
        "parsed" : {
                "storage" : {
                        "dbPath" : "C:\\NodeJS\\MongoDB\\data\\db",
                        "engine" : "mmapv1"
                }
        },
        "ok" : 1
}


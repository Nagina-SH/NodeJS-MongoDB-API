db.collection.updateOne

db.people.updateOne({name : "Shailendra"}, {$set : {name : "UpdateOne"} })
db.myColl.find()
{ "_id" : 1, "category" : "café", "status" : "A" }
{ "_id" : 2, "category" : "cafe", "status" : "a" }
{ "_id" : 3, "category" : "cafE", "status" : "a" }


db.myColl.createIndex(
{category : 1}
)

db.myColl.getIndexes() 

The single field index on the field cat has the user-specified name of catIdx [2] and the index specification document of { "cat" : -1 }.


db.myColl.getIndexes()
[
        {
                "v" : 1,
                "key" : {
                        "_id" : 1
                },
                "name" : "_id_",
                "ns" : "test.myColl"
        },
        {
                "v" : 1,
                "key" : {
                        "category" : 1
                },
                "name" : "category_1",
                "ns" : "test.myColl"
        },
        {
                "v" : 1,
                "key" : {
                        "category" : -1
                },
                "name" : "category_-1",
                "ns" : "test.myColl",
                "status" : -1
        }
]




db.myColl.dropIndex( "category_1" );
db.myColl.dropIndex( {"_id" : 1} );



db.myColl.dropIndexes()

db.myColl.find().explain();
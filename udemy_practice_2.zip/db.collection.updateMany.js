db.collection.updateMany

db.people.find({name: "joe"})


db.people.find({name: "joe"})
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe2"), "name" : "joe", "age" : 80, "DOB" : 1989 }
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe3"), "name" : "joe", "age" : 70 }
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe4"), "name" : "joe", "age" : 71 }
{ "_id" : ObjectId("5a3a08645900ab4e384292be"), "name" : "joe", "age" : 65 }
{ "_id" : ObjectId("5a3a08645900ab4e384292bf"), "name" : "joe", "age" : 70 }
{ "_id" : ObjectId("5a3a08645900ab4e384292c0"), "name" : "joe", "age" : 71 }



db.people.updateMany({name: "joe"}, {$set: {name: "Joe Update"}} )

db.people.find({name : "Joe Update"})
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe2"), "name" : "Joe Update", "age" : 80, "DOB" : 1989 }
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe3"), "name" : "Joe Update", "age" : 70 }
{ "_id" : ObjectId("5a38b4dc708eeadfc873bbe4"), "name" : "Joe Update", "age" : 71 }
{ "_id" : ObjectId("5a3a08645900ab4e384292be"), "name" : "Joe Update", "age" : 65 }
{ "_id" : ObjectId("5a3a08645900ab4e384292bf"), "name" : "Joe Update", "age" : 70 }
{ "_id" : ObjectId("5a3a08645900ab4e384292c0"), "name" : "Joe Update", "age" : 71 }


db.inspectors .insert([
{ "_id" : 92412, "inspector" : "F. Drebin", "Sector" : 1, "Patrolling" : true },
{ "_id" : 92413, "inspector" : "J. Clouseau", "Sector" : 2, "Patrolling" : false },
{ "_id" : 92414, "inspector" : "J. Clouseau", "Sector" : 3, "Patrolling" : true },
{ "_id" : 92415, "inspector" : "R. Coltrane", "Sector" : 3, "Patrolling" : false }
])

db.inspectors.updateMany(
      { "Sector" : { $gt : 4 }, "inspector" : "R. Coltrane" },
      { $set: { "Patrolling" : false } },
      { upsert: true }

	  
	  {
        "acknowledged" : true,
        "matchedCount" : 0,
        "modifiedCount" : 0,
        "upsertedId" : ObjectId("5a4224ce664856b52a175fc9")
}



db.inspectors.find()
{ "_id" : 92412, "inspector" : "F. Drebin", "Sector" : 1, "Patrolling" : true }
{ "_id" : 92413, "inspector" : "J. Clouseau", "Sector" : 2, "Patrolling" : false }
{ "_id" : 92414, "inspector" : "J. Clouseau", "Sector" : 3, "Patrolling" : true }
{ "_id" : 92415, "inspector" : "R. Coltrane", "Sector" : 3, "Patrolling" : false }
{ "_id" : ObjectId("5a4224ce664856b52a175fc9"), "inspector" : "R. Coltrane", "Patrolling" : false }


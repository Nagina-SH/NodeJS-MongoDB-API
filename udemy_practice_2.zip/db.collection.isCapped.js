db.collection.isCapped


db.students.isCapped()
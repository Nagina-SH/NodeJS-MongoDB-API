cursor.max

db.products.remove({})
db.products.insert([
{ "_id" : 6, "item" : "apple", "type" : "cortland", "price" : 1.29 },
{ "_id" : 2, "item" : "apple", "type" : "fuji", "price" : 1.99 },
{ "_id" : 1, "item" : "apple", "type" : "honey crisp", "price" : 1.99 },
{ "_id" : 3, "item" : "apple", "type" : "jonagold", "price" : 1.29 },
{ "_id" : 4, "item" : "apple", "type" : "jonathan", "price" : 1.29 },
{ "_id" : 5, "item" : "apple", "type" : "mcintosh", "price" : 1.29 },
{ "_id" : 7, "item" : "orange", "type" : "cara cara", "price" : 2.99 },
{ "_id" : 10, "item" : "orange", "type" : "navel", "price" : 1.39 },
{ "_id" : 9, "item" : "orange", "type" : "satsuma", "price" : 1.99 },
{ "_id" : 8, "item" : "orange", "type" : "valencia", "price" : 0.99 }
])


db.products.createIndex(
{"item" : 1, "type" : 1}
)

db.products.createIndex(
{"item" : 1, "type" : -1}
)

db.products.createIndex(
{"price" : 1 }
)

db.products.getIndexes()

db.products.find().max( { item: 'apple', type: 'jonagold' } ).hint( { item: 1, type: 1 } )
{ "_id" : 6, "item" : "apple", "type" : "cortland", "price" : 1.29 }
{ "_id" : 2, "item" : "apple", "type" : "fuji", "price" : 1.99 }
{ "_id" : 1, "item" : "apple", "type" : "honey crisp", "price" : 1.99 }


db.products.find().min( { price: 1.39 } ).max( { price: 1.99 } ).hint( { price: 1 } )
{ "_id" : 10, "item" : "orange", "type" : "navel", "price" : 1.39 }

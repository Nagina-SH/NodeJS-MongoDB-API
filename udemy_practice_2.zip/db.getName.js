db.getName

//the current database name

db.getName()
test

db.collection.renameCollection

db.students.renameCollection("class")
db.class.renameCollection("students")


db.students.find()



db.class.find()
{ "_id" : 1, "score" : [ -1, 3 ] }
{ "_id" : 2, "score" : [ 1, 5 ] }
{ "_id" : 3, "score" : [ 5, 5 ] }



db.class.renameCollection("students")
{ "ok" : 1 }


db.class.find()


db.students.find()
{ "_id" : 1, "score" : [ -1, 3 ] }
{ "_id" : 2, "score" : [ 1, 5 ] }
{ "_id" : 3, "score" : [ 5, 5 ] }



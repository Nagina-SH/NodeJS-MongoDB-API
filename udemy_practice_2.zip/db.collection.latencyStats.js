db.collection.latencyStats()

db.students.latencyStats()


db.students.latencyStats( { histograms: true } )

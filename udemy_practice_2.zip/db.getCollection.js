var authColl = db.getCollection("auth");

authColl.insertOne(
   {
       usrName : "Shailendra Doe",
       usrDept : "IT",
       usrTitle : "Manager",
       authLevel : 2,
       authDept : [ "Database"]
   }
)
{
        "acknowledged" : true,
        "insertedId" : ObjectId("5a45e387cb9011971b4c9133")
}



db.auth.insertOne(
   {
       usrName : "Shailendra Doe",
       usrDept : "IT",
       usrTitle : "Manager",
       authLevel : 2,
       authDept : [ "Database"]
   }
)
The operation errors as db.auth() method has no insertOne method.

db.auth()
Error: auth expects either (username, password) or ({ user: username, pwd: password })
0



db.collection.dataSize()

db.myColl.dataSize()
336

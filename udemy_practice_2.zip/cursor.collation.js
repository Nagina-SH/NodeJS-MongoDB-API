cursor.collation

db.foo.insert([
{ "_id" : 51, "x" : "a" },
{ "_id" : 52, "x" : "A" },
{ "_id" : 53, "x" : "á" }
])


db.foo.find( { x: "a" } ).collation( { locale: "en_US", strength: 1 } )

db.foo.find( { x: "a" } ).collation( { locale: "en_US", strength: 1 } )
2017-12-26T17:46:30.272+0530 E QUERY    [thread1] TypeError: db.foo.find(...).collation is not a function :
@(shell):1:1

db.version()
3.2.18

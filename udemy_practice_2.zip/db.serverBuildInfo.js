db.serverBuildInfo()
{
        "version" : "3.2.18",
        "gitVersion" : "4c1bae566c0c00f996a2feb16febf84936ecaf6f",
        "targetMinOS" : "Windows Vista/Windows Server 2008",
        "modules" : [ ],
        "allocator" : "tcmalloc",
        "javascriptEngine" : "mozjs",
        "sysInfo" : "deprecated",
        "versionArray" : [
                3,
                2,
                18,
                0
        ],
        "openssl" : {
                "running" : "disabled",
                "compiled" : "disabled"
        },
        "buildEnvironment" : {
                "distmod" : "",
                "distarch" : "i386",
                "cc" : "cl: Microsoft (R) C/C++ Optimizing Compiler Version 18.00.31101 for x86",
                "ccflags" : "/nologo /EHsc /W3 /wd4355 /wd4800 /wd4267 /wd4244 /wd4290 /wd4068 /wd4351 /we4013 /we4099 /we4930 /Z7 /errorReport:none /MT /O2 /Oy- /Gw /Gy /Zc:inline",
                "cxx" : "cl: Microsoft (R) C/C++ Optimizing Compiler Version 18.00.31101 for x86",
                "cxxflags" : "/TP",
                "linkflags" : "/nologo /DEBUG /INCREMENTAL:NO /LARGEADDRESSAWARE /OPT:REF",
                "target_arch" : "i386",
                "target_os" : "windows"
        },
        "bits" : 32,
        "debug" : false,
        "maxBsonObjectSize" : 16777216,
        "storageEngines" : [
                "devnull",
                "ephemeralForTest",
                "mmapv1"
        ],
        "ok" : 1
}


db.getCollectionInfos

db.getCollectionInfos()
[
        {
                "name" : "auth",
                "options" : {

                }
        },
        {
                "name" : "bios",
                "options" : {

                }
        },
        {
                "name" : "characters",
                "options" : {

                }
        },
        {
                "name" : "collection",
                "options" : {

                }
        },
        {
                "name" : "employees",
                "options" : {

                }
        },
        {
                "name" : "foo",
                "options" : {

                }
        },
        {
                "name" : "foodColl",
                "options" : {

                }
        },
        {
                "name" : "inspectors",
                "options" : {

                }
        },
        {
                "name" : "inventory",
                "options" : {

                }
        },
        {
                "name" : "map_reduce_example",
                "options" : {

                }
        },
        {
                "name" : "movie",
                "options" : {

                }
        },
        {
                "name" : "myColl",
                "options" : {

                }
        },
        {
                "name" : "orders",
                "options" : {

                }
        },
        {
                "name" : "people",
                "options" : {

                }
        },
        {
                "name" : "processes",
                "options" : {

                }
        },
        {
                "name" : "products",
                "options" : {

                }
        },
        {
                "name" : "replace_col",
                "options" : {

                }
        },
        {
                "name" : "stackover",
                "options" : {

                }
        },
        {
                "name" : "stacktest",
                "options" : {

                }
        },
        {
                "name" : "students",
                "options" : {

                }
        },
        {
                "name" : "survey",
                "options" : {

                }
        },
        {
                "name" : "system.indexes",
                "options" : {

                }
        },
        {
                "name" : "users",
                "options" : {

                }
        }
]
db.single.find({$text : {$search: 'blood'} })
db.single.find( { $text: { $search: "blood" } } )

db.single.createIndex( { beginning: "text" } )

// stop word

db.single.find({$text : {$search: 'the'} })
db.single.find({$text : {$search: 'stands'} })
db.single.find({$text : {$search: 'work'} })


db.multi.createIndex({beginning: 'text'}, {default_language: 'french'})

db.multi.find({$text : {$search: 'Brothers'} })
db.multi.find({$text : {$search: 'war'} })
db.multi.find({$text : {$search: 'Winter'} })
db.multi.find({$text : {$search: 'winter'} })
db.multi.find({$text : {$search: 'stands'} })
db.multi.find({$text : {$search: 'and'} })

db.multi.find({$text : {$search: 'konigin'} })
db.multi.find({$text : {$search: 'konigin', $diacriticSensitive: true} })

db.multi.find({$text : {$search: 'Konig',$diacriticSensitive: true} })

db.books.createIndex( {author: 'text'} )


db.books.find({$text : {$search: 'card'} })
db.books.find({$text : {$search: 'house'} })
db.books.find({$text : {$search: 'dummy'} })

db.books.dropIndexes()

db.books.createIndex( {'$**': 'text' } )



db.books.update({_id: 1}, {$set: {review: 'This is a dummy value'}})


load('C:/NodeJS/resources/scripts/text/initComments.js')

initTC.help()
initTC.init()
db.comments.findOne()

db.comments.createIndex({text: 'text'})

db.comments.createIndex({date:1, text: 'text'})

db.comments.find({date:ISODate("2016-06-09T00:00:00Z"), $text: {$search: '0bwx6r3vgc'} })

db.comments.find({date: {$gt : ISODate("2016-06-09T00:00:00Z") }, $text: {$search: '0bwx6r3vgc'} })

use geo
db.points2d.createIndex({coordinates: '2d'})

db.points2d.find({coordinates: {$near: [4,3]} })

db.points2d.find({coordinates: {$near: [4,3]} }).sort({_id: -1})

db.points2d.find({coordinates: {$near: [4,3], $minDistance:2, $maxDistance: 3} })

db.points2d.find({coordinates: {$geoWithin: {$center: [[1,0],2] }} })

db.shapes2ds.createIndex({location: '2d'})

db.shapes2ds.createIndex({location: '2dsphere'})

db.shape2ds.insert({_id: 5, name: 'test', location: {type: 'Point', coordinates: [181, 20] } })



db.shapes2ds.find({location: {$geoIntersects: {$geometry: {type: 'Polygon', coordinates: [[[4,1],[5,2],[2,5],[1,4], [4,1] ]]}} } })

db.capitals.createIndex({location: '2dsphere'})


db.capitals.find({location: {$near: {$geometry: {type: 'Point', coordinates: [12.26, 51.24]}} }} )



db.language.aggregate([
{
	$match: {
		seats: {$gte: 10}
	}
}
])

db.language.aggregate([
{
	$match: {
		seats: {$gte: 10}
	}
}
]).pretty()


db.language.find({
	seats: {$gte: 10}
})


db.language.aggregate([
{
	$match: {
		seats: {$gte: 10},
		language: 'english',
		price: {$lt: 200}
	}
}
]).pretty()



db.language.aggregate([
{
	$match: {
		$or: [
			{price: {$lt: 200}},
			{seats: {$lt: 10}}
		]
		
	}
}
]).pretty()


db.language.aggregate([
{
	$project: {
		school: 1,
		language: 1
	},
	$match: {
		$or: [
			{price: {$lt: 200}},
			{seats: {$lt: 10}}
		]
		
	}
}
]).pretty()

db.getCollection('language').find({})


db.language.aggregate([
{
	$project: {
		'teacher.firstName': 1
	}
}
])


db.language.aggregate([
{
	$project: {
		income: {
			$multiply: ['$seats','$price']
		}
	}
}
]).pretty()


db.language.aggregate([
{
	$project: {
		seats: 1,
		price: 1,
		income: {
			$multiply: ['$seats','$price']
		}
	}
}
]).pretty()





db.language.aggregate([
{ $redact: {
        $cond: {
           if: { $eq: ['$school', 'Prestige'] },
           then: "$$KEEP",
           else: "$$PRUNE"
         }
       }
}
]).pretty()


db.language.aggregate([
{ $redact: {
        $cond: {
           if: { $eq: ['$school', 'Prestige'] },
           then: "$$DESCEND",
           else: "$$PRUNE"
         }
       }
}
]).pretty()



db.language.aggregate([
{ $redact: {
        $cond: {
           if: { $eq: ['$teacher.details.class', 1] },
           then: "$$DESCEND",
           else: "$$PRUNE"
         }
       }
}
]).pretty()


db.language.aggregate([
{
	$project: {
		school:1,
		language:1,
		seats:1,
		teacher:1,
		'details.class': {$literal:1}
	}
},
{ $redact: {
        $cond: {
           if: { $eq: ['$details.class', 1] },
           then: "$$DESCEND",
           else: "$$PRUNE"
         }
       }
},
{
	$project: {
		school:1,
		language:1,
		seats:1,
		teacher:1
	}
}
]).pretty()



db.language.aggregate([
{
	$project: {
		school:1,
		language:1,
		seats:1,
		teacher:1,
		'details.class': {$literal:1}
	}
},
{ $redact: {
        $cond: {
           if: { $eq: ['$details.class', 1] },
           then: "$$DESCEND",
           else: "$$PRUNE"
         }
       }
}
]).pretty()







db.languageR.aggregate([
{ $redact: {
        $cond: {
           if: { $eq: ['$teacher.details.class', 1] },
           then: "$$DESCEND",
           else: "$$PRUNE"
         }
       }
}
]).pretty()



db.languageR.aggregate([
{
	$project: {
		school:1,
		language:1,
		seats:1,
		teacher:1,
		'details.class': {$literal:1}
	}
},
{ $redact: {
        $cond: {
           if: { $eq: ['details.class', 1] },
           then: "$$DESCEND",
           else: "$$PRUNE"
         }
       }
},
{
	$project: {
		school:1,
		language:1,
		seats:1,
		teacher:1
	}
}
]).pretty()




db.languageR.aggregate([
{
	$project: {
		school:1,
		language:1,
		seats:1,
		teacher:1,
		'details.class': {$literal:1}
	}
},
{ $redact: {
        $cond: {
           if: { $eq: ['details.class', 1] },
           then: "$$DESCEND",
           else: "$$PRUNE"
         }
       }
}
]).pretty()



db.language.aggregate([
{
	$group: {
		_id: '$school',
		courses: {$sum: 1}
	}
}
])


db.language.aggregate([
{
	$group: {
		_id: '$school',
		allSeats: {$sum: '$seats'}
	}
}
])


db.language.aggregate([
{
	$group: {
		_id: '$language',
		avgSeats: {$avg: '$seats'}
	}
}
])

db.language.aggregate([
{
	$group: {
		_id: '$school',
		languages: {$push: '$language'}
	}
}
])


db.language.aggregate([
{
	$group: {
		_id: '$school',
		languages: {$addToSet: '$language'}
	}
}
])


db.language.aggregate([
{
	$group: {
		_id: {school: '$school',language: '$language'},
		totalSeats: {$sum: '$seats'}
	}
}
])



db.capitals.aggregate([
{
	$geoNear: {
		spherical: true,
		near: [20,50],
		distanceField: 'distance',
		maxDistance: 0.1
	}
}
]).pretty()

db.capitals.aggregate([
{
	$geoNear: {
		spherical: true,
		near: [20,50],
		distanceField: 'distance',
		maxDistance: 0.1,
		distanceMultiplier: 6371
	}
}
]).pretty()


db.capitals.aggregate([
{
	$geoNear: {
		spherical: true,
		near: {type: 'Point', coordinates: [20,50]},
		distanceField: 'distance',
		maxDistance: 700000
	}
}
]).pretty()



db.capitals.aggregate([
{
	$geoNear: {
		spherical: true,
		near: {type: 'Point', coordinates: [20,50]},
		distanceField: 'distance',
		maxDistance: 700000,
		minDistance: 300000,
		num: 2,
		limit: 3
	}
}
]).pretty()




db.capitals.aggregate([
{
	$geoNear: {
		spherical: true,
		near: {type: 'Point', coordinates: [20,50]},
		distanceField: 'distance',
		maxDistance: 700000,
		minDistance: 300000,
	}
},
	{
		$sort : {distance: -1}
	}

]).pretty()




db.unwind.aggregate([
{
	$unwind: '$survivalItems'
}
])

db.unwind.aggregate([
{
	$unwind: '$name'
}
])


db.unwind.updateOne(
{_id: 3}, {$set: {survivalItems: 'knife'} }
)

db.unwind.aggregate([
{
	$unwind: '$name'
}
])


db.unwind.aggregate([
{
	$unwind: { 
		path: '$survivalItems'
	}
	
}
])


db.unwind.aggregate([
{
	$unwind: { 
		path: '$survivalItems',
		preserveNullAndEmptyArrays: true
	}
}
])


db.unwind.aggregate([
{
	$unwind: { 
		path: '$survivalItems',
		preserveNullAndEmptyArrays: true,
		includeArrayIndex: 'index'
	}
}
])



db.language.aggregate([
{
	$group: {
		_id: '$school',
		count: {$sum: 1}
	}
},
{
	$out: 'aggresult'
}
])


db.language.aggregate([
{
	$group: {
		_id: '$school',
		allSeats: {$sum: '$seats'}
	}
},
{
	$out: 'aggresult'
}
])




db.runCommand({
	collMod: 'aggresult',
	validator: {count: {$gt: 3}}
})


db.language.aggregate([
{
	$group: {
		_id: '$school',
		count: {$sum: 1}
	}
},
{
	$out: 'aggresult'
}
],
{bypassDocumentValidation: true}
)



db.language.aggregate([
{
	$group: {
		_id: '$school',
		count: {$sum: 1}
	}
})


db.language.find().pretty()

db.runCommand({
	collMod: 'aggresult',
	validator: {}
})

db.aggresult.createIndex({name: 1}, {unique: true} )


db.language.aggregate([
{
	$project: {
		name: 1
	}
},
{
	$out: 'aggresult'
}
])


db.language.aggregate([
{
	$project: {
		name: 1
	}
}
])



db.unwind.aggregate([
{
	$unwind: '$survivalItems'
}, 
{
	$out: 'aggresult'
}
],
{bypassDocumentValidation: true}
)


db.unwind.aggregate([
{
	$unwind: '$survivalItems'
},
{
	$project: {
		_id: 0,
		survivalItems: 1
	}
},
 
{
	$out: 'aggresult'
}
])



db.unwind.aggregate([
{
	$unwind: '$survivalItems'
},
{
	$project: {
		_id: 1,
		survivalItems: 1
	}
}
])



db.people.aggregate([
{
	$lookup: {
		from: 'cars',
		foreignField: 'personId',
		localField: '_id',
		as: 'cars'
	}
}
]).pretty()


db.car.updateMany({}, {$unset: {carIds: ''}})

db.people.updateOne({_id : 2}, {$set: {carIds: [1,2]}})




db.people.find([
{
	$unwind: '$carIds'
},
{
	$lookup: {
		from: 'cars',
		foreignField: '_id',
		localField: 'carIds',
		as: 'cars'
	}
}
])














cursor.returnKey

db.students.getIndexes()

db.students.count()

var csr = db.students.find( { } )

csr.returnKey()

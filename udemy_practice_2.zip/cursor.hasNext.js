cursor.hasNext

db.stacktest.find().forEach( function(aRow) { 
					//print( JSON.stringify("row: " + aRow.fields ) ); 
					
					var newFields = [];

					aRow.fields.forEach( function( aField ){
						var newItems = [];

						print( "item_array: " + aField.items );
						
						aField.items.forEach(function(item) {
							print( JSON.stringify("item: " + item ) );
							var aNewItem = { item: parseInt(item), ref: 0 };
							newItems.push(aNewItem);
						})
						
						newFields.push({_id: aField._id, items: newItems });
					})
					print(db.stacktest.find().hasNext());
					// db.stacktest.update(
						// {_id :aRow._id }, 
							// {$set : {"Fields" : newFields} }
					// );
})
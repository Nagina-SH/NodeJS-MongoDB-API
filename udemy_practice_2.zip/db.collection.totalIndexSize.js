db.collection.totalIndexSize

db.students.totalIndexSize()


db.students.storageSize()
8192



db.students.totalIndexSize()
8176


db.students.getIndexes() 


db.students.find()
{ "_id" : 1, "score" : [ -1, 3 ] }
{ "_id" : 2, "score" : [ 1, 5 ] }
{ "_id" : 3, "score" : [ 5, 5 ] }



db.students.createIndex(
   { score: 1}
   )
{
        "createdCollectionAutomatically" : false,
        "numIndexesBefore" : 1,
        "numIndexesAfter" : 2,
        "ok" : 1
}

db.students.totalIndexSize()
16352



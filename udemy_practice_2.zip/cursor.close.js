cursor.close

db.collection.find(<query>).close()
db.getMongo()
connection to 127.0.0.1

// db.getMongo() runs when the shell initiates. Use this command to test that the mongo shell has a connection to the proper database instance.


the current database name
db.collection.validate();

db.orders.validate()
{
        "ns" : "test.orders",
        "datasize" : 2224,
        "nrecords" : 13,
        "lastExtentSize" : 8192,
        "firstExtent" : "0:1df000 ns:test.orders",
        "lastExtent" : "0:1df000 ns:test.orders",
        "extentCount" : 1,
        "firstExtentDetails" : {
                "loc" : "0:1df000",
                "xnext" : "null",
                "xprev" : "null",
                "nsdiag" : "test.orders",
                "size" : 8192,
                "firstRecord" : "0:1df0b0",
                "lastRecord" : "0:1df930"
        },
        "deletedCount" : 1,
        "deletedSize" : 5584,
        "nIndexes" : 1,
        "keysPerIndex" : {
                "test.orders.$_id_" : 13
        },
        "valid" : true,
        "errors" : [ ],
        "warning" : "Some checks omitted for speed. use {full:true} option to do more thorough scan.",
        "ok" : 1
}

var bulk = db.users.initializeOrderedBulkOp();
bulk.insert( { user: "abc123", status: "A", points: 0 } );
bulk.insert( { user: "ijk123", status: "A", points: 0 } );
bulk.insert( { user: "mop123", status: "P", points: 0 } );
bulk.find( { status: "D" } ).remove();
bulk.find( { status: "P" } ).update( { $set: { comment: "Pending" } } );
bulk.execute();


db.users.find().pretty()
{
        "_id" : ObjectId("5a38b996708eeadfc873bbe5"),
        "name" : "joe",
        "age" : 30,
        "sex" : "male",
        "location" : "Wisconsin",
        "favorite book" : [
                "Cat's Cradle",
                "Ender's Game"
        ]
}





var bulk = db.users.initializeOrderedBulkOp();
bulk.insert( { user: "abc123", status: "A", points: 0 } );
bulk.insert( { user: "ijk123", status: "A", points: 0 } );
bulk.insert( { user: "mop123", status: "P", points: 0 } );
bulk.find( { status: "D" } ).remove();
bulk.find( { status: "P" } ).update( { $set: { comment: "Pending" } } );
bulk.execute();
BulkWriteResult({
        "writeErrors" : [ ],
        "writeConcernErrors" : [ ],
        "nInserted" : 3,
        "nUpserted" : 0,
        "nMatched" : 1,
        "nModified" : 1,
        "nRemoved" : 0,
        "upserted" : [ ]
})
db.users.find().pretty()
{
        "_id" : ObjectId("5a38b996708eeadfc873bbe5"),
        "name" : "joe",
        "age" : 30,
        "sex" : "male",
        "location" : "Wisconsin",
        "favorite book" : [
                "Cat's Cradle",
                "Ender's Game"
        ]
}
{
        "_id" : ObjectId("5a4b1ef1bef470abc86fbbb3"),
        "user" : "abc123",
        "status" : "A",
        "points" : 0
}
{
        "_id" : ObjectId("5a4b1ef1bef470abc86fbbb4"),
        "user" : "ijk123",
        "status" : "A",
        "points" : 0
}
{
        "_id" : ObjectId("5a4b1ef1bef470abc86fbbb5"),
        "user" : "mop123",
        "status" : "P",
        "points" : 0,
        "comment" : "Pending"
}

bulk.getOperations();
[
        {
                "originalZeroIndex" : 0,
                "batchType" : 1,
                "operations" : [
                        {
                                "_id" : ObjectId("5a4b1ef1bef470abc86fbbb3"),
                                "user" : "abc123",
                                "status" : "A",
                                "points" : 0
                        },
                        {
                                "_id" : ObjectId("5a4b1ef1bef470abc86fbbb4"),
                                "user" : "ijk123",
                                "status" : "A",
                                "points" : 0
                        },
                        {
                                "_id" : ObjectId("5a4b1ef1bef470abc86fbbb5"),
                                "user" : "mop123",
                                "status" : "P",
                                "points" : 0
                        }
                ]
        },
        {
                "originalZeroIndex" : 3,
                "batchType" : 3,
                "operations" : [
                        {
                                "q" : {
                                        "status" : "D"
                                },
                                "limit" : 0
                        }
                ]
        },
        {
                "originalZeroIndex" : 4,
                "batchType" : 2,
                "operations" : [
                        {
                                "q" : {
                                        "status" : "P"
                                },
                                "u" : {
                                        "$set" : {
                                                "comment" : "Pending"
                                        }
                                },
                                "multi" : true,
                                "upsert" : false
                        }
                ]
        }
]



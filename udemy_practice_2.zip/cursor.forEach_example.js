db.stacktest.insert([
{
    "title" : "record 1",
    "fields" : [ 
        {
            "_id" : 1,
            "items" : [ 
                1
            ]
        },
        {
            "_id" : 2,
            "items" : [ 
                2,3,4
            ]
        },
        {
            "_id" : 3,
            "items" : [ 
                5
            ]
}
    ]
},

{
        "title" : "record 2",
        "fields" : [ 
            {
                "_id" : 4,
                "items" : [ 
                    7,8,9,10
                ]
            },
            {
                "_id" : 5,
                "items" : [ 

                ]
            },
            {
                "_id" : 6,
                "items" : [ 
                    11,12
                ]
            }
        ]
    }
])	;


var t = db.aTable.find();

t.forEach(function( aRow ) {
    aRow.fields.forEach( function( aField ){
        aField.items.forEach( function( item ){
            var aNewItem = { item: parseInt(item), ref: 0 };
            db.aTable.update(item, {$set:aNewItem})
        } )
    } )
});

db.stacktest.find().forEach( function(myDoc) { print( "title: " + myDoc.title ); } );
title: record 1
title: record 2

db.stacktest.find().forEach( function(aRow) { 
					//print( "row: " + aRow.fields ); 
					
					aRow.fields.forEach( function( aField ){
						print( "item_array: " + aField.items );
						
						aField.items.forEach(function(item) {
							print( "item: " + item );
							var aNewItem = { item: parseInt(item), ref: 0 };
							
							print( "aNewItem: " + aNewItem );
							//db.aTable.update(item, {$set:aNewItem})

						})
					})
})	



db.stacktest.find().forEach( function(aRow) { 
					//print( JSON.stringify("row: " + aRow.fields ) ); 
					var newFields = [];

					aRow.fields.forEach( function( aField ){
						var newItems = [];

						print( "item_array: " + aField.items );
						
						aField.items.forEach(function(item) {
							print( JSON.stringify("item: " + item ) );
							var aNewItem = { item: parseInt(item), ref: 0 };
							newItems.push(aNewItem);
						})
						
						newFields.push({_id: aField._id, items: newItems });
					})
					
					db.stacktest.update(
						{_id :aRow._id }, 
							{$set : {"Fields" : newFields} }
					);
})

db.aTable.find().forEach(function (itemWrapper){
    itemWrapper.fields.forEach(function(field){
        var items = field.items;
        var newItems = [];
        items.forEach(function(item){
          var t = {'item':item,'key':0}
          newItems.push(t);      
        })
        field.items = newItems;
    })
    db.aTable.save(itemWrapper)
})














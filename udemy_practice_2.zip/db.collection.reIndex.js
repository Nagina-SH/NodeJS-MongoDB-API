db.students.reIndex()

db.students.getIndexes() 
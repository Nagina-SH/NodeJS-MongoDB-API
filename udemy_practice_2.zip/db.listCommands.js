db.listCommands

// Provides a list of all database commands. See the Database Commands document for a more extensive index of these options.

db.system.js.save(
 {
     _id: "echoFunction",
     value : function(x) { return x; }
 }
);
WriteResult({
        "nMatched" : 0,
        "nUpserted" : 1,
        "nModified" : 0,
        "_id" : "echoFunction"
})

db.system.js.save(
 {
    _id : "myAddFunction" ,
    value : function (x, y){ return x + y; }
 }
);
WriteResult({
        "nMatched" : 0,
        "nUpserted" : 1,
        "nModified" : 0,
        "_id" : "myAddFunction"
})





db
admin


db.system.js.find()
{ "_id" : "echoFunction", "value" : function (x) { return x; } }
{ "_id" : "myAddFunction", "value" : function (x, y){ return x + y; } }

db.loadServerScripts()
echoFunction(3);
3

myAddFunction(3, 5);
8


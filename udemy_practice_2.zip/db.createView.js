db.createView

db.createView(<view>, <source>, <pipeline>, <options>)

db.survey .insert([
{ _id: 1, empNumber: "abc123", feedback: { management: 3, environment: 3 }, department: "A" },
{ _id: 2, empNumber: "xyz987", feedback: { management: 2, environment: 3 }, department: "B" },
{ _id: 3, empNumber: "ijk555", feedback: { management: 3, environment: 4 }, department: "C" }
])

db.createView(
   "managementFeedback",
   "survey",
   [ { $project: { "management": "$feedback.management", department: 1 } } ]
)
2017-12-29T11:20:20.265+0530 E QUERY    [thread1] TypeError: db.createView is not a function :
@(shell):1:1


// Views work in MongoDb since version 3.4, so instead of RoboMongo one might need Robo 3T. And of course this will work is shell as well. (Assuming old installations are upgraded to 3.4 as described at https://docs.mongodb.com/master/release-notes/3.4/#upgrade.)
db.collection.stats()

db.students.stats()

db.students.stats( { indexDetails : true } )
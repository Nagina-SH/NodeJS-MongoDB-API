db.collection.getShardDistribution()

db.students.getShardDistribution()
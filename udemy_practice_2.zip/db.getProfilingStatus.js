//This method provides a wrapper around the database command “profile” and returns the current profiling level.

db.getProfilingStatus()
{ "was" : 0, "slowms" : 100 }
db.serverStatus()
{
        "host" : "PUNTE18301SFJ3",
        "advisoryHostFQDNs" : [
                "PUNTE18301SFJ3.iuser.iroot.adidom.com"
        ],
        "version" : "3.2.18",
        "process" : "C:\\Program Files\\MongoDB\\Server\\3.2\\bin\\mongod.exe",
        "pid" : NumberLong(4472),
        "uptime" : 4667,
        "uptimeMillis" : NumberLong(4667960),
        "uptimeEstimate" : 4664,
        "localTime" : ISODate("2017-12-29T10:26:40.967Z"),
        "asserts" : {
                "regular" : 0,
                "warning" : 0,
                "msg" : 0,
                "user" : 0,
                "rollovers" : 0
        },
        "backgroundFlushing" : {
                "flushes" : 77,
                "total_ms" : 4778,
                "average_ms" : 62.05194805194805,
                "last_ms" : 25,
                "last_finished" : ISODate("2017-12-29T10:25:53.218Z")
        },
        "connections" : {
                "current" : 1,
                "available" : 999999,
                "totalCreated" : NumberLong(2)
        },
        "extra_info" : {
                "note" : "fields vary by platform",
                "page_faults" : 72444,
                "usagePageFileMB" : 41,
                "totalPageFileMB" : 6950,
                "availPageFileMB" : 4134,
                "ramMB" : 3476,
                "wow64Process" : false
        },
        "globalLock" : {
                "totalTime" : NumberLong("4667956000"),
                "currentQueue" : {
                        "total" : 0,
                        "readers" : 0,
                        "writers" : 0
                },
                "activeClients" : {
                        "total" : 7,
                        "readers" : 0,
                        "writers" : 0
                }
        },
        "locks" : {
                "Global" : {
                        "acquireCount" : {
                                "r" : NumberLong(74487),
                                "w" : NumberLong(38),
                                "W" : NumberLong(3)
                        }
                },
                "MMAPV1Journal" : {
                        "acquireCount" : {
                                "r" : NumberLong(37220),
                                "w" : NumberLong(453)
                        }
                },
                "Database" : {
                        "acquireCount" : {
                                "r" : NumberLong(37215),
                                "R" : NumberLong(8),
                                "W" : NumberLong(38)
                        }
                },
                "Collection" : {
                        "acquireCount" : {
                                "R" : NumberLong(39419),
                                "W" : NumberLong(3)
                        }
                },
                "Metadata" : {
                        "acquireCount" : {
                                "w" : NumberLong(1),
                                "W" : NumberLong(56)
                        }
                }
        },
        "network" : {
                "bytesIn" : NumberLong(11669),
                "bytesOut" : NumberLong(62333),
                "numRequests" : NumberLong(150)
        },
        "opcounters" : {
                "insert" : 0,
                "query" : 7,
                "update" : 2,
                "delete" : 0,
                "getmore" : 0,
                "command" : 143
        },
        "opcountersRepl" : {
                "insert" : 0,
                "query" : 0,
                "update" : 0,
                "delete" : 0,
                "getmore" : 0,
                "command" : 0
        },
        "storageEngine" : {
                "name" : "mmapv1",
                "supportsCommittedReads" : false,
                "persistent" : true
        },
        "tcmalloc" : {
                "generic" : {
                        "current_allocated_bytes" : 0,
                        "heap_size" : 1048576
                },
                "tcmalloc" : {
                        "pageheap_free_bytes" : 0,
                        "pageheap_unmapped_bytes" : 1032192,
                        "max_total_thread_cache_bytes" : NumberLong(1073741824),
                        "current_total_thread_cache_bytes" : 16,
                        "total_free_bytes" : 16384,
                        "central_cache_free_bytes" : 16368,
                        "transfer_cache_free_bytes" : 0,
                        "thread_cache_free_bytes" : 16,
                        "aggressive_memory_decommit" : 0,
                        "formattedString" : "------------------------------------------------\nMALLOC:              0 (    0.0 MiB) Bytes in use by application\nMALLOC: +            0 (    0.0 MiB) Bytes in page heap freelist\nMALLOC: +        16368 (    0.0 MiB) Bytes in central cache freelist\nMALLOC: +            0 (    0.0 MiB) Bytes in transfer cache freelist\nMALLOC: +           16 (    0.0 MiB) Bytes in thread cache freelists\nMALLOC: +       727272 (    0.7 MiB) Bytes in malloc metadata\nMALLOC:   ------------\nMALLOC: =       743656 (    0.7 MiB) Actual memory used (physical + swap)\nMALLOC: +      1032192 (    1.0 MiB) Bytes released to OS (aka unmapped)\nMALLOC:   ------------\nMALLOC: =      1775848 (    1.7 MiB) Virtual address space used\nMALLOC:\nMALLOC:              4              Spans in use\nMALLOC:              1              Thread heaps in use\nMALLOC:           8192              Tcmalloc page size\n------------------------------------------------\nCall ReleaseFreeMemory() to release freelist memory to the OS (via madvise()).\nBytes released to the OS take up virtual address space but no physical memory.\n"
                }
        },
        "writeBacksQueued" : false,
        "mem" : {
                "bits" : 32,
                "resident" : 88,
                "virtual" : 363,
                "supported" : true,
                "mapped" : 240
        },
        "metrics" : {
                "commands" : {
                        "aggregate" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "buildInfo" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(2)
                        },
                        "collStats" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(23)
                        },
                        "count" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(2)
                        },
                        "currentOp" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "find" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(6)
                        },
                        "getCmdLineOpts" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "hostInfo" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "isMaster" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(98)
                        },
                        "killOp" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "listCollections" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(5)
                        },
                        "listCommands" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "listDatabases" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "logout" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "repairDatabase" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "replSetGetStatus" : {
                                "failed" : NumberLong(1),
                                "total" : NumberLong(1)
                        },
                        "resetError" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "serverStatus" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        },
                        "update" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(2)
                        },
                        "whatsmyuri" : {
                                "failed" : NumberLong(0),
                                "total" : NumberLong(1)
                        }
                },
                "cursor" : {
                        "timedOut" : NumberLong(0),
                        "open" : {
                                "noTimeout" : NumberLong(0),
                                "pinned" : NumberLong(0),
                                "total" : NumberLong(0)
                        }
                },
                "document" : {
                        "deleted" : NumberLong(0),
                        "inserted" : NumberLong(0),
                        "returned" : NumberLong(43),
                        "updated" : NumberLong(2)
                },
                "getLastError" : {
                        "wtime" : {
                                "num" : 0,
                                "totalMillis" : 0
                        },
                        "wtimeouts" : NumberLong(0)
                },
                "operation" : {
                        "fastmod" : NumberLong(0),
                        "idhack" : NumberLong(0),
                        "scanAndOrder" : NumberLong(0),
                        "writeConflicts" : NumberLong(0)
                },
                "queryExecutor" : {
                        "scanned" : NumberLong(0),
                        "scannedObjects" : NumberLong(43)
                },
                "record" : {
                        "moves" : NumberLong(0)
                },
                "repl" : {
                        "executor" : {
                                "counters" : {
                                        "eventCreated" : 0,
                                        "eventWait" : 0,
                                        "cancels" : 0,
                                        "waits" : 0,
                                        "scheduledNetCmd" : 0,
                                        "scheduledDBWork" : 0,
                                        "scheduledXclWork" : 0,
                                        "scheduledWorkAt" : 0,
                                        "scheduledWork" : 0,
                                        "schedulingFailures" : 0
                                },
                                "queues" : {
                                        "networkInProgress" : 0,
                                        "dbWorkInProgress" : 0,
                                        "exclusiveInProgress" : 0,
                                        "sleepers" : 0,
                                        "ready" : 0,
                                        "free" : 0
                                },
                                "unsignaledEvents" : 0,
                                "eventWaiters" : 0,
                                "shuttingDown" : false,
                                "networkInterface" : "NetworkInterfaceASIO inShutdown: 0"
                        },
                        "apply" : {
                                "attemptsToBecomeSecondary" : NumberLong(0),
                                "batches" : {
                                        "num" : 0,
                                        "totalMillis" : 0
                                },
                                "ops" : NumberLong(0)
                        },
                        "buffer" : {
                                "count" : NumberLong(0),
                                "maxSizeBytes" : 268435456,
                                "sizeBytes" : NumberLong(0)
                        },
                        "network" : {
                                "bytes" : NumberLong(0),
                                "getmores" : {
                                        "num" : 0,
                                        "totalMillis" : 0
                                },
                                "ops" : NumberLong(0),
                                "readersCreated" : NumberLong(0)
                        },
                        "preload" : {
                                "docs" : {
                                        "num" : 0,
                                        "totalMillis" : 0
                                },
                                "indexes" : {
                                        "num" : 0,
                                        "totalMillis" : 0
                                }
                        }
                },
                "storage" : {
                        "freelist" : {
                                "search" : {
                                        "bucketExhausted" : NumberLong(0),
                                        "requests" : NumberLong(264),
                                        "scanned" : NumberLong(0)
                                }
                        }
                },
                "ttl" : {
                        "deletedDocuments" : NumberLong(0),
                        "passes" : NumberLong(77)
                }
        },
        "ok" : 1
}


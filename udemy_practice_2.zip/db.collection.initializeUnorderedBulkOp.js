db.collection.initializeUnorderedBulkOp

var bulk = db.users.initializeUnorderedBulkOp();
bulk.insert( { user: "abc123", status: "A", points: 0 } );
bulk.insert( { user: "ijk123", status: "A", points: 0 } );
bulk.insert( { user: "mop123", status: "P", points: 0 } );
bulk.insert( { user: "mop45639202920", status: "X", points: 0 } );
bulk.insert( { user: "mop123", status: "P", points: 0 } );
bulk.insert( { user: "mop45639202921", status: "Y", points: 0 } );
bulk.execute();


bulk.getOperations()
bulk.getOperations(); 
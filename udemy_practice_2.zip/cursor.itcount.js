cursor.itcount
// Counts the number of documents remaining in a cursor.

db.stacktest.find().forEach( function(aRow) { 
					//print( JSON.stringify("row: " + aRow.fields ) ); 
					var newFields = [];
db.stacktest.find().itcount()
					aRow.fields.forEach( function( aField ){
						var newItems = [];

						print( "item_array: " + aField.items );
						
						aField.items.forEach(function(item) {
							print( JSON.stringify("item: " + item ) );
							var aNewItem = { item: parseInt(item), ref: 0 };
							newItems.push(aNewItem);
						})
						
						newFields.push({_id: aField._id, items: newItems });
					})
					
					db.stacktest.update(
						{_id :aRow._id }, 
							{$set : {"Fields" : newFields} }
					);
})
db.products.save( { item: "book", qty: 40 } )

db.products.find()
{ "_id" : 10, "item" : "large box", "qty" : 20 }
{ "_id" : 11, "item" : "small box", "qty" : 55 }
{ "_id" : 12, "item" : "medium box", "qty" : 30 }
{ "_id" : 13, "item" : "envelopes", "qty" : 60 }
{ "_id" : ObjectId("5a41da82e275d6418fbef7bc"), "item" : "card", "qty" : 15 }
{ "_id" : ObjectId("5a41da82e275d6418fbef7bd"), "item" : "envelope", "qty" : 20 }
{ "_id" : ObjectId("5a41da82e275d6418fbef7be"), "item" : "stamps", "qty" : 30 }
{ "_id" : ObjectId("5a41da8ee275d6418fbef7bf"), "item" : "card", "qty" : 15 }
{ "_id" : ObjectId("5a41da8ee275d6418fbef7c0"), "item" : "envelope", "qty" : 20 }
{ "_id" : ObjectId("5a41da8ee275d6418fbef7c1"), "item" : "stamps", "qty" : 30 }
{ "_id" : ObjectId("5a42151ee275d6418fbef7c4"), "item" : "book", "qty" : 40 }


db.products.save( { _id: 10, item: "water", qty: 30 } )

db.products.find()
{ "_id" : 10, "item" : "water", "qty" : 30 }
{ "_id" : 11, "item" : "small box", "qty" : 55 }
{ "_id" : 12, "item" : "medium box", "qty" : 30 }
{ "_id" : 13, "item" : "envelopes", "qty" : 60 }
{ "_id" : ObjectId("5a41da82e275d6418fbef7bc"), "item" : "card", "qty" : 15 }
{ "_id" : ObjectId("5a41da82e275d6418fbef7bd"), "item" : "envelope", "qty" : 20 }
{ "_id" : ObjectId("5a41da82e275d6418fbef7be"), "item" : "stamps", "qty" : 30 }
{ "_id" : ObjectId("5a41da8ee275d6418fbef7bf"), "item" : "card", "qty" : 15 }
{ "_id" : ObjectId("5a41da8ee275d6418fbef7c0"), "item" : "envelope", "qty" : 20 }
{ "_id" : ObjectId("5a41da8ee275d6418fbef7c1"), "item" : "stamps", "qty" : 30 }
{ "_id" : ObjectId("5a42151ee275d6418fbef7c4"), "item" : "book", "qty" : 40 }


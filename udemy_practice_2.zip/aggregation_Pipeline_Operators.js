db.ratings.insert([
{ _id: 5, start: 5, end: 8 },
{ _id: 2, start: 4, end: 4 },
{ _id: 3, start: 9, end: 7 },
{ _id: 4, start: 6, end: 7 }
])


db.ratings.aggregate([
   {
     $project: { delta: { $abs: { $subtract: [ "$start", "$end" ] } } }
   }
])


db.ratings.aggregate([{delta: {$abs: {$subtract: ["$start","$end"] }}}])

db.sales.insert([
{"_id" : 1, "item" : "abc", "price" : 10, "fee" : 2, date: ISODate("2014-03-01T08:00:00Z") },
{ "_id" : 2, "item" : "jkl", "price" : 20, "fee" : 1, date: ISODate("2014-03-01T09:00:00Z") },
{ "_id" : 3, "item" : "xyz", "price" : 5,  "fee" : 0, date: ISODate("2014-03-15T09:00:00Z") }
])

db.sales.find().pretty()



db.sales.aggregate([
	{$project: {item: 1, total: {$add: ["$price", "$fee"] } }} 
]).pretty()


db.sales.remove({})

db.sales.insert([
{ "_id" : 1,"item" : "abc", "price" : 10, "quantity" : 2, "date" : ISODate("2014-01-01T08:00:00Z") },
{ "_id" : 2, "item" : "jkl", "price" : 20, "quantity" : 1, "date" : ISODate("2014-02-03T09:00:00Z") },
{ "_id" : 3, "item" : "xyz", "price" : 5, "quantity" : 5, "date" : ISODate("2014-02-03T09:05:00Z") },
{ "_id" : 4, "item" : "abc", "price" : 10, "quantity" : 10, "date" : ISODate("2014-02-15T08:00:00Z") },
{ "_id" : 5, "item" : "xyz", "price" : 5, "quantity" : 10, "date" : ISODate("2014-02-15T09:12:00Z") }]
)


db.sales.aggregate([
{$group : {
	_id: {day: {$dayOfYear: "$date" }, year: {$year: "$date"} },
	itemsSold: {$addToSet: "$item"}
}}
])

db.sales.aggregate([
{$group : {
	_id: {day: {$dayOfYear: "$date" } },
	itemsSold: {$addToSet: "$item"}
}}
])

db.sales.aggregate([
{$group : {
	_id: {date: "$date"},
	itemsSold: {$addToSet: "$item"}
}}
])


db.survey.insert([
{ "_id" : 1, "responses" : [ true ] },
{ "_id" : 2, "responses" : [ true, false ] },
{ "_id" : 3, "responses" : [ ] },
{ "_id" : 4, "responses" : [ 1, true, "seven" ] },
{ "_id" : 5, "responses" : [ 0 ] },
{ "_id" : 6, "responses" : [ [ ] ] },
{ "_id" : 7, "responses" : [ [ 0 ] ] },
{ "_id" : 8, "responses" : [ [ false ] ] },
{ "_id" : 9, "responses" : [ null ] },
{ "_id" : 10, "responses" : [ undefined ] }
])

db.survey.find().pretty()

db.survey.aggregate(
   [
     { $project: { responses: 1, isAllTrue: { $allElementsTrue: [ "$responses" ] }, _id: 0 } }
   ]
)


db.survey.aggregate(
   [
     { $project: { responses: 1, isAllTrue: { $allElementsTrue: [ "$responses" ] }} }
   ]
)

db.inventory .insert([
{ "_id" : 1, "item" : "abc1", description: "product 1", qty: 300 },
{ "_id" : 2, "item" : "abc2", description: "product 2", qty: 200 },
{ "_id" : 3, "item" : "xyz1", description: "product 3", qty: 250 },
{ "_id" : 4, "item" : "VWZ1", description: "product 4", qty: 300 },
{ "_id" : 5, "item" : "VWZ2", description: "product 5", qty: 180 }
])

db.inventory.find().pretty()
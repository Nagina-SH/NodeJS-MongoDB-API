db.collection.drop()

db.orders.drop()
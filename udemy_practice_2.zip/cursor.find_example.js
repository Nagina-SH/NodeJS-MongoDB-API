var cursor = db.stacktest.find();
printjson(cursor[2]);
print( "cursor: " + JSON.stringify(cursor[0] ) );



{"_id":{},"title":"record1","fields":[
 {"_id":1,"items":[1]}, 
 {"_id":2,"items":[2,3,4]},
 {"_id":3,"items":[5]}],
 "Fields":[
 {"_id":1,"items":[
	{"item":1,"ref":0}]},
 {"_id":2,"items":[
	{"item":2,"ref":0},
	{"item":3,"ref":0},
	{"item":4,"ref":0}]},
{"_id":3,"items":[
 {"item":5,"ref":0}]}]}

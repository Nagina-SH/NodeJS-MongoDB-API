db.getReplicationInfo
// Returns a document with the status of the replica set, using data polled from the oplog. Use this output when diagnosing issues with replication.

db.getReplicationInfo()
{ "errmsg" : "neither master/slave nor replica set replication detected" }


var command =
  {
    "aggregate": "orders", // name of the collection on which we run this command
    "pipeline": [
      { $match: { status: "A" } },
      { $group: { _id: "$cust_id", total: { $sum: 1 } } },
      { $sort: { total: -1 } }
    ]
  }

  db.orders.find({}, {"status" : 1, "cust_id" : 1, "orders" : 1 } )
{ "_id" : 5, "cust_id" : "abc1", "status" : "A" }
{ "_id" : 9, "cust_id" : "abc1", "status" : "A" }
{ "_id" : 13, "cust_id" : "abc1", "status" : "A" }
{ "_id" : 7, "cust_id" : "xyz1", "status" : "D" }
{ "_id" : 14, "cust_id" : "abc1", "status" : "A" }
{ "_id" : 11, "cust_id" : "xyz1", "status" : "D" }
{ "_id" : 15, "cust_id" : "abc1", "status" : "A" }
{ "_id" : ObjectId("50a8240b927d5d8b5891743c"), "cust_id" : "abc123", "status" : "A" }
{ "_id" : ObjectId("50a8240b927d5d8b5891743d"), "cust_id" : "abc123", "status" : "A" }
{ "_id" : ObjectId("50a8240b927d5d8b5891743e"), "cust_id" : "abc123", "status" : "A" }
{ "_id" : ObjectId("50a8240b927d5d8b5891743f"), "cust_id" : "abc123", "status" : "A" }
{ "_id" : ObjectId("5a41f294e275d6418fbef7c2"), "cust_id" : "abc125", "status" : "A" }
{ "_id" : ObjectId("5a41f294e275d6418fbef7c3"), "cust_id" : "abc126", "status" : "A" }

  
  
db.runCommand(command)
{
        "waitedMS" : NumberLong(0),
        "result" : [
                {
                        "_id" : "abc1",
                        "total" : 5
                },
                {
                        "_id" : "abc123",
                        "total" : 4
                },
                {
                        "_id" : "abc126",
                        "total" : 1
                },
                {
                        "_id" : "abc125",
                        "total" : 1
                }
        ],
        "ok" : 1
}

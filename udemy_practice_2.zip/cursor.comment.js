cursor.comment


db.students.find().comment( "Find all Manhattan restaurants" )

cursor.sort

db.people.find({}, {name : 1}).sort( { name: 1 } )


db.orders.insert(
[{ _id: 1, cust_id: "abc1", ord_date: ISODate("2012-11-02T17:04:11.102Z"), status: "A", amount: 50 },
{ _id: 2, cust_id: "xyz1", ord_date: ISODate("2013-10-01T17:04:11.102Z"), status: "A", amount: 100 },
{ _id: 3, cust_id: "xyz1", ord_date: ISODate("2013-10-12T17:04:11.102Z"), status: "D", amount: 25 },
{ _id: 4, cust_id: "xyz1", ord_date: ISODate("2013-10-11T17:04:11.102Z"), status: "D", amount: 125 },
{ _id: 5, cust_id: "abc1", ord_date: ISODate("2013-11-12T17:04:11.102Z"), status: "A", amount: 25 }]
);

db.orders.aggregate([
	{$match: {status : "A"}},
	{$group: {"_id" : "$cust_id", total: { $sum: "$amount" } } },
])

db.orders.aggregate(
                     [
                       { $group: { _id: "$cust_id", total: { $sum: "$amount" } } },
                       { $sort: { total: -1 } },
                       { $limit: 2 }
                     ],
                     {
                       cursor: { batchSize: 0 }
                     }
                   )
				   
				   
db.myColl.insert([
{ _id: 1, category: "café", status: "A" },
{ _id: 2, category: "cafe", status: "a" },
{ _id: 3, category: "cafE", status: "a" }
])				   


db.foodColl.insert([
   { _id: 1, category: "cake", type: "chocolate", qty: 10 },
   { _id: 2, category: "cake", type: "ice cream", qty: 25 },
   { _id: 3, category: "pie", type: "boston cream", qty: 20 },
   { _id: 4, category: "pie", type: "blueberry", qty: 15 }
])

db.foodColl.aggregate(
   [ { $sort: { qty: 1 }},
         { $match: { category: "cake", qty: 10  } },
        { $group: { _id: "$category", total: { $sum: "$qty" } } },
         { $sort: { type: -1 } }
        ]
)

db.foodColl.aggregate(
   [ { $match: { category: "cake"} },
	{ $group: { _id: "$category", total: { $sum: "$qty" } } },	 
	 { $sort: { type: -1 } } 
	]
)


















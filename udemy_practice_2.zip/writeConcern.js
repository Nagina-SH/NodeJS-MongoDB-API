db.products.insert(
   { item: "envelopes", qty : 100, type: "Clasp" },
   { writeConcern: { w: 2, wtimeout: 5000 } }
)
WriteResult({
        "writeError" : {
                "code" : 2,
                "errmsg" : "cannot use 'w' > 1 when a host is not replicated"
        }
})

db.products.insert(
   { item: "envelopes", qty : 100, type: "Clasp" },
   { writeConcern: { w: 1, wtimeout: 5000 } }
)
WriteResult({ "nInserted" : 1 })



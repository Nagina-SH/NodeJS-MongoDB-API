db.collection.insert([
{ "_id": "apples", "qty": 5 },
{ "_id": "bananas", "qty": 7 },
{ "_id": "oranges", "qty": { "in stock": 8, "ordered": 12 } },
{ "_id": "avocados", "qty": "fourteen" }
])


db.collection.find({qty: {$gt: 4} });

db.collection.find({"_id" : "bananas"});

db.collection.find({qty: {$gt: 5, $lt: 11 } });

db.students.insert([
{ "_id" : 1, "score" : [ -1, 3 ] },
{ "_id" : 2, "score" : [ 1, 5 ] },
{ "_id" : 3, "score" : [ 5, 5 ] }
]);

db.students.find({ "score" : {$gt : 0, $lt : 2} })

db.bios.findOne(
   {
      awards: {
                $elemMatch: {
                     award: "Turing Award",
                     year: { $gt: 1990 }
                }
      }
   }
)


db.stackover.insert([
{
"_id" : "76561198045636214",
"timecreated" : 1311148549,

"unusual" : [
{
    "id" : 1960169991,
    "original_id" : 698672623,
    "defindex" : 313,
    "_particleEffect" : 19
},
{
    "id" : 965349033,
    "original_id" : 931933064,
    "defindex" : 363,
    "_particleEffect" : 6
}
]
}
])


db.stackover.find({ "unusual": {"$elemMatch":{
									"defindex":363,
									"_particleEffect":{"$in":[6,19]}  }
								} 
					})

db.stackover.find({ "unusual": {"$elemMatch":{ "defindex":363}} })
db.stackover.find({ "unusual": {"$elemMatch":{ "defindex":363, "_particleEffect":{"$in":[6,19]}}} })					




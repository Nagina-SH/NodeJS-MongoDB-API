db.characters.copyTo("employees")
WARNING: db.eval is deprecated
2

db.employees.find()
{ "_id" : 4, "char" : "Dithras", "class" : "barbarian", "lvl" : 4 }
{ "_id" : 5, "char" : "Taeln", "class" : "fighter", "lvl" : 3 }

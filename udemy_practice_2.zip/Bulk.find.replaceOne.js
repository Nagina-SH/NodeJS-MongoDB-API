var bulk = db.items.initializeUnorderedBulkOp();
bulk.find( { item: "xyz123" } ).replaceOne( { item: "abc123", status: "P", points: 100 } );
bulk.execute();
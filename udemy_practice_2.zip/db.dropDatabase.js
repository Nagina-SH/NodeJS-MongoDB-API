use dropdb
switched to db dropdb



db.movie.insert({"name":"tutorials point"})
WriteResult({ "nInserted" : 1 })



show dbs
admin   0.078GB
dropdb  0.078GB
local   0.078GB
test    0.078GB




use dropdb
switched to db dropdb

db.dropDatabase();
{ "dropped" : "dropdb", "ok" : 1 }

db
dropdb


show dbs
admin  0.078GB
local  0.078GB
test   0.078GB


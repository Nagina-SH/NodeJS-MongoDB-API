db.setProfilingLevel

db.setProfilingLevel()
{ "was" : 0, "slowms" : 100, "ok" : 1 }
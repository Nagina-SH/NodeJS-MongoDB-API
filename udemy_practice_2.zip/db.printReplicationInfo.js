db.printReplicationInfo

db.printReplicationInfo()
{ "errmsg" : "neither master/slave nor replica set replication detected" }

cursor.map

db.people.find().map( function(u) { return u.name; } );